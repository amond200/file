package controller;

import common.ICommon;
import common.Utils;
import data.Protocol;
import network.Client;
import view.MainView;

public class SocketCommController implements IClientController, ICommon{
	public final static String DEFAULT_IP 					= "127.0.0.1";
	public final static String DEFAULT_IP_TEXT 				= "localhost";
	public final static String DEFAULT_LGMV_PORT 			= "61000";

	public final static String MESSAGE_NEED_CONNECT	 		= "통신 연결이 필요합니다.";
	public final static String MESSAGE_WAIT_CONNECT 		= "잠시 후 시도하시기 바랍니다.";
	public final static String MESSAGE_FILE_SAVE_FINISH	 	= " 파일이 저장되었습니다.";

	private Client mClient;
	
	private MainView mView;
	private Protocol mProtocol;

	private int mConnectStatus = SOCKET_STATUS_STOP;

//	DataMonitoringView dataMonitoringView;
//	DataMonitoringController dataMonitoringController;
	
//	private Protocol lgmvParser;
//	private int lgmvSaveCounter = 0;
//	private DataManager dataManager = null;
//	private int dataSaveStatus = DATA_SAVE_STATUS_STOP;

	
	
	public SocketCommController(MainView view, Protocol protocol) {
		this.mView = view;
		this.mProtocol = protocol;
				
//		dataManager = new DataManager();
//		dataManager.initialize(this, VIEW_ID_SAVE_FILE);
//		dataMonitoringView = new DataMonitoringView();
//		dataMonitoringController = dataMonitoringView.getController();
	}

	public boolean onClickLGMVConnectButton() {
		boolean ret = false;
		if(mConnectStatus == SOCKET_STATUS_CONNECT) {
			if(mClient !=  null) {
				mConnectStatus = SOCKET_STATUS_STOP;
				mClient.close();
				mClient = null;
			}
		}else {
			try {
				String ip = mView.getLGMVIP();
				String portStr = mView.getLGMVPort();
				int port = Integer.parseInt(portStr);
				mClient = new Client(ip, port, this, VIEW_ID_LGMV);
				boolean result = mClient.connect();
				if(result == true) {
					ret = true;
					mConnectStatus = SOCKET_STATUS_CONNECT;
					mClient.start();
				} else {
					mConnectStatus = SOCKET_STATUS_CONNECT_ERROR;
				}
			} catch (Exception e) {
				e.printStackTrace();
				mConnectStatus = SOCKET_STATUS_CONNECT_ERROR;
			}
		}

		mView.setLGMVConnectStatus(mConnectStatus);

		switch(mConnectStatus) {
		case SOCKET_STATUS_STOP : 
			this.printLog(VIEW_ID_LGMV, "LGMV Socket Closed..");
			break;
		case SOCKET_STATUS_CONNECT_ERROR : 
			this.printLog(VIEW_ID_LGMV, "LGMV Connect Fail!");
			break;
		case SOCKET_STATUS_CONNECT : 
			this.printLog(VIEW_ID_LGMV, "LGMV Connect Success!!");
			break;
		}
		return ret;
	}

//	public void onClickLGMVInitButton() {
//		if(lgmvConnectStatus != SOCKET_STATUS_CONNECT) {
//			view.setLGMVIP(DEFAULT_IP);
//			view.setLGMVPort(DEFAULT_LGMV_PORT);
//		}
//	}


//	public void onClickFileSaveButton() {
//		if(dataSaveStatus == DATA_SAVE_STATUS_STOP) { // START!!
//			startFileSaving();
//		}else { // STOP..
//			stopFileSaving();
//		}
//	}
	
//	private void startFileSaving() {
//		if(lgmvClient == null || calorimeterClient == null) {
//			view.showMessage(MESSAGE_NEED_CONNECT);
//			return;
//		}
//		if(lgmvSaveCounter < SAVE_MINIMUM_COUNT || calorimeterSaveCounter < SAVE_MINIMUM_COUNT) {
//			view.showMessage(MESSAGE_WAIT_CONNECT);
//			return;
//		}
//		
//		if(dataManager == null) {
//			dataManager = new DataManager();
//			dataManager.initialize(this, VIEW_ID_SAVE_FILE);
//		}
//
//		String tempFileName = view.getSaveFileName(); 
//		if(tempFileName == null || tempFileName.length() < 1) {
//			tempFileName = "savefile";
//		}
//		tempFileName.replace(".csv", "");
//		tempFileName += "_";
//		tempFileName += DateUtils.longTimeToStringFileSaveFormat(System.currentTimeMillis());
//		tempFileName += ".csv";
//		view.setSaveFileName(tempFileName);
//		boolean result = dataManager.startSavingFile(SAVE_PERIOD, view.getSavePath(), tempFileName);
//		if(result == true) {
//			view.setSaveFileConnectStatus(DATA_SAVE_STATUS_SAVING);
//			dataSaveStatus = DATA_SAVE_STATUS_SAVING ;
//		}else{
//			view.setSaveFileName("");
//			view.showMessage(MESSAGE_FILE_SAVE_ERROR);
//		}
//	}
	
//	private void stopFileSaving() {
//		view.setSaveFileConnectStatus(DATA_SAVE_STATUS_STOP);
//		dataSaveStatus = DATA_SAVE_STATUS_STOP ;
//		String saveFileName = 	view.getSaveFileName();
//		view.setSaveFileName("");
//		dataManager.stopSavingFile();
//		view.showMessage("\""+saveFileName+"\""+MESSAGE_FILE_SAVE_FINISH);
//		dataManager = new DataManager();
//		dataManager.initialize(this, VIEW_ID_SAVE_FILE);
//	}

//	public void onClickShowDetailViewButton() {
//		dataMonitoringView.setVisible(true);
//	}

	public void printLog(int modelID, String log) {

	}

	public void putParsing(String str) {
		Utils.printLog(Utils.LogType.INFO, "putParsing: " + str);
		if (mProtocol == null) {
			return;
		}
		
		Protocol.ParsingStatus status = mProtocol.parsing(str);
		if (status == Protocol.ParsingStatus.FINISH) {
//			System.out.println("parsingText: " + mProtocol.getParsingText());
			if (mProtocol.updateData(mProtocol.getParsingText())) {
				mView.setProtocolItem(mProtocol.getDataList());;
			}
			mProtocol.setParsingCount(0);
			mProtocol.clearParsingText();
		} else if (status == Protocol.ParsingStatus.NONE) {
			mProtocol.setParsingCount(0);
			mProtocol.clearParsingText();
		}
		
//		String parsingText = mProtocol.parsing(str);
//		
//		System.out.println("parsingText: " + parsingText);
//
//		if (mProtocol.updateData(parsingText)) {
//			mView.setProtocolItem(mProtocol.getDataList());;
//		}
		
	}
	
	public void socketClose(int clientID) {
//		boolean colseFlag = false;
//		if(clientID == VIEW_ID_LGMV) {
//			if(lgmvConnectStatus == SOCKET_STATUS_CONNECT) {
//				lgmvConnectStatus = SOCKET_STATUS_CONNECT_ERROR;
//				lgmvClient = null;
//				lgmvSaveCounter = 0;
//				view.setLGMVConnectStatus(lgmvConnectStatus);
//				colseFlag = true;
//			}
//		}
//		if(colseFlag == true) {
//			if(dataSaveStatus == DATA_SAVE_STATUS_SAVING) {
//				stopFileSaving();
//			}
//		}
	}
}