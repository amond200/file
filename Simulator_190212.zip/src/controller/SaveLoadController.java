package controller;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import common.IProtocolParserId;
import common.Utils;
import data.DataVO;
import data.Protocol;
import data.ProtocolModel;
import view.MainView;

public class SaveLoadController implements IProtocolParserId{

	public static final String ID_MODEL = "model";
	public static final String ID_DATA = "data";

	public static final int DEFAULT_INT_VALUE = -1;

	public String fileExtensions = ".json";

	private MainView mView;
	private Protocol mProtocol;

	public SaveLoadController(MainView view, Protocol protocol) {
		this.mView = view;
		this.mProtocol = protocol;
	}


	@SuppressWarnings("unchecked")
	public boolean doSaveData(String modelName) {
		if (modelName == null || modelName.trim().isEmpty()) {
			return false;
		}
		JSONObject jsonObj = new JSONObject();
		List<ProtocolModel> list = new ArrayList<>();
		for (ProtocolModel saveModel : mProtocol.getProtocolList()) {
			list.add(saveModel);
		}
		
		jsonObj.put(ID_MODEL, modelName);
		JSONArray pageArray = new JSONArray();
		for (ProtocolModel page : list) {
			pageArray.add(page.pageName);	//0
			pageArray.add(page.pageCount);	//1
			pageArray.add(page.pageSize);	//2
			pageArray.add(page.integrityType);	//3
			pageArray.add(page.rxHeaderId);	//4
			JSONArray dataArray = new JSONArray();
			for (DataVO pdata : page.mData) {
				dataArray.add(pdata.getId());
				dataArray.add(pdata.getIntValue());
				dataArray.add(pdata.getPosByte());
				dataArray.add(pdata.getPosBit());
			}
			pageArray.add(dataArray);
		}
		jsonObj.put(ID_DATA, pageArray);

		if (jsonObj != null && jsonObj.size() > 0) {
			fileWrite(jsonObj, modelName);
			return true;
		}
		return false;
	}

	private void fileWrite(JSONObject jsonObj, String fileName) {
		FileWriter file = null;
		try {
			file = new FileWriter(fileName + fileExtensions);
			file.write(jsonObj.toJSONString());
			file.flush();
			Utils.printLog(Utils.LogType.INFO, "Created Save File.");
		} catch(IOException e) {
			Utils.printLog(Utils.LogType.ERR, e.getMessage());
		} finally {
			try {
				if(file != null) file.close();
			} catch (IOException e) {
				Utils.printLog(Utils.LogType.ERR, "Could not create save file");
			}
		}

	}

	public boolean doLoadData(String modelName) {
		if (modelName == null || modelName.trim().isEmpty()) {
			return false;
		}
		JSONObject jsonObj = loadFile(modelName);
		if (jsonObj == null) {
			Utils.printLog(Utils.LogType.ERR, "jsonObj is null");
			return false;
		}

		Utils.printLog(Utils.LogType.INFO, "model: " + (String)jsonObj.get(ID_MODEL));

		JSONArray pageArray = (JSONArray) jsonObj.get(ID_DATA);

		List<ProtocolModel> modelList = new ArrayList<>();
		List<DataVO> dummyData = new ArrayList<>();	

		for(int pageIdx = 0; pageIdx < pageArray.size(); pageIdx = pageIdx + 6) {
			Utils.printLog(Utils.LogType.DEBUG, "===== pageArray index: " + pageIdx);
			String pageName = (String)pageArray.get(pageIdx + 0);	
			int pageCount = ((Long)pageArray.get(pageIdx + 1)).intValue();
			int size = ((Long)pageArray.get(pageIdx + 2)).intValue();
			String igType = (String)pageArray.get(pageIdx + 3);	
			int intergrity = ((Long)pageArray.get(pageIdx + 4)).intValue();
			List<DataVO> data = new ArrayList<>();	
			JSONArray dataArray = (JSONArray)pageArray.get(pageIdx + 5);
			for(int dataIdx = 0; dataIdx < dataArray.size(); dataIdx = dataIdx + 4) {
				String id = (String)dataArray.get(dataIdx + 0);	// class java.lang.String
				Long tmp = (Long)dataArray.get(dataIdx + 1);	// class java.lang.Long
				int intValue = tmp != null ? tmp.intValue() : DEFAULT_INT_VALUE;
				List<Integer> posByte  = Utils.convertToInt((JSONArray)dataArray.get(dataIdx + 2));	// class org.json.simple.JSONArray
				List<Integer> posBit = Utils.convertToInt((JSONArray)dataArray.get(dataIdx + 3));		// class org.json.simple.JSONArray
				data.add(new DataVO(pageName, pageCount, id, posByte, posBit, intValue));

			}
			modelList.add(new ProtocolModel(pageName, pageCount, size, igType, intergrity, data));
			dummyData.addAll(data);
		}

		for(ProtocolModel pm : modelList) {
			Utils.printLog(Utils.LogType.DEBUG, pm.toString());
		}

		if (modelList != null && modelList.size() > 0) {
			mProtocol.setProtocolList(modelList);
			mView.clearPageTable();
			mView.addPageItem(mProtocol.getProtocolList());
			
			mView.clearProtocolTable();
			mView.addProtocolItem(mProtocol.getDataList());
			return true;
		}
		return false;
	}

	private JSONObject loadFile(String filename) {
		JSONObject jsonObj = null;
		JSONParser jsonParser = new JSONParser();
		FileReader file;
		try {
			file = new FileReader(filename + fileExtensions);
			jsonObj = (JSONObject)jsonParser.parse(file);
		} catch (Exception e) {
			System.err.println(e);
		}
		return jsonObj;
	}


}
