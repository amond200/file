package common;

public interface IProtocolParserId {
	
	public static final int PRODUCT_TYPE_MINI4 = 50;
	
	// 모델명
	public static final String MODEL_SYNC4 = "Sync4";
	public static final String MODEL_SYNC5 = "Sync5";

	// 페이지정보 
	public static final String TYPE_SYSTEM = "System";
	public static final String TYPE_CYCLE = "Cycle";
	public static final String TYPE_COMM_COUNT = "CommCnt";
	public static final String TYPE_DEV_DATA = "DevData";
	public static final String TYPE_IDU = "IDU";

	public static final String DEFAULT_HEADER_ID_OPER_MODE = "oper_mode";
	public static final String DEFAULT_HEADER_ID_ERROR_UNIT_NUMBER = "err_unit_number";
	public static final String DEFAULT_HEADER_ID_ERROR_NUMBER = "error_number"; //TODO

	// System
	public static final String SYSTEM_INFO_STX = "system_page_stx"; // add
	public static final String SYSTEM_INFO_PAGE_NO = "system_page_no";	// add
	public static final String SYSTEM_INFO_PRODUCT_TYPE = "system_product_type";	// add
	public static final String SYSTEM_INFO_TOTAL_IDU_NUM = "Total_IDU_Number";	// add
	public static final String SYSTEM_INFO_TOTAL_HRU_NUM = "Total_HRU_Number";	// add

	// Cycle
	public static final String CYCLE_PAGE_NO = "cycle_page_no"; // add


	public static final String SYSTEM_INFO_ENTRY = "system_entry_no";	// add
	public static final String CYCLE_INFO_ENTRY = "cycle_entry_no";	// add
	
	/*
	 * 밑에 정의된 값은 protocol_parser_defined.h 파일과 동일
	 */

	// ODU::Basic
	public static final String ODU_HEADER_ID_HIGHPRESSURE_TARGET = "highpress_target";
	public static final String ODU_HEADER_ID_HIGHPRESSURE_TRACE = "highpress_trace";
	public static final String ODU_HEADER_ID_LOWPRESSURE_TARGET = "lowpress_target";
	public static final String ODU_HEADER_ID_LOWPRESSURE_TRACE = "lowpress_trace";
	public static final String ODU_HEADER_ID_SH_TARGET = "sh_target";
	public static final String ODU_HEADER_ID_SH_TRACE = "sh_trace";
	public static final String ODU_HEADER_ID_SCSH_TARGET = "scsh_target";
	public static final String ODU_HEADER_ID_SCSH_TRACE = "scsh_trace";
	public static final String ODU_HEADER_ID_SC_TRACE = "sc_trace";
	public static final String ODU_HEADER_ID_IDU_TEMP_WEIGHTED_AVG = "idu_temp_weighted_average";
	public static final String ODU_HEADER_ID_COMP_RATIO = "comp_ratio";

	// ODU::Cycle info
	public static final String ODU_HEADER_ID_PORT_ACCUM_VALVE = "port_accum_valve";
	public static final String ODU_HEADER_ID_PORT_4WAY = "port_4way";
	public static final String ODU_HEADER_ID_PORT_HEX_HIGH_VALVE = "port_hex_high_valve";
	public static final String ODU_HEADER_ID_PORT_HEX_LOW_VALVE = "port_hex_low_valve";
	public static final String ODU_HEADER_ID_PORT_RECEIVER_IN = "port_receiver_in";
	public static final String ODU_HEADER_ID_PORT_RECEIVER_OUT = "port_receiver_out";
	public static final String ODU_HEADER_ID_SUCTION_VALVE = "suction_valve";
	public static final String ODU_HEADER_ID_PORT_INV_PREHEAT = "port_inv_preheat";
	public static final String ODU_HEADER_ID_PORT_INV2_PREHEAT = "port_inv2_perheat";
	public static final String ODU_HEADER_ID_HEX_VALVE = "hex_valve";
	public static final String ODU_HEADER_ID_COMP1_OIL_LEVEL = "comp1_oil_level";
	public static final String ODU_HEADER_ID_COMP2_OIL_LEVEL = "comp2_oil_level";
	public static final String ODU_HEADER_ID_SNOW_DEEP = "snow_deep";

	public static final String ODU_HEADER_ID_HOT_GAS = "TXT_HOTGAS"; // from mini4
	public static final String ODU_HEADER_ID_DRAIN_PAN_HEATER = "TXT_DRAIN_PAN_HEATER"; // from mini4
	public static final String ODU_HEADER_ID_BASE_PAN_HEATER = "TXT_BASE_PAN_HEATER"; // from mini4
	public static final String ODU_HEADER_ID_VAPOR_INJECTION = "TXT_VAPOR_INJECTION"; // from mini4

	public static final String ODU_HEADER_ID_PORT_4WAY2 = "port_4way2";
	public static final String ODU_HEADER_ID_OIL_BALANCE = "TXT_OIL_BALANCE";
	public static final String ODU_HEADER_ID_OIL_CONTROL1 = "TXT_OIL_CONTROL1";
	public static final String ODU_HEADER_ID_OIL_CONTROL2 = "TXT_OIL_CONTROL2";
	public static final String ODU_HEADER_ID_DRY_CONTACT = "TXT_DRY_CONTACT";
	
	// ODU::Actuator
	public static final String ODU_HEADER_ID_INV1_TARGET = "inv1_target";
	public static final String ODU_HEADER_ID_INV1_TRACE = "inv1_trace";
	public static final String ODU_HEADER_ID_INV2_TARGET = "inv2_target";
	public static final String ODU_HEADER_ID_INV2_TRACE = "inv2_trace";
	public static final String ODU_HEADER_ID_FAN1_TARGET = "fan1_target";
	public static final String ODU_HEADER_ID_FAN1_TRACE = "fan1_trace";
	public static final String ODU_HEADER_ID_FAN2_TRACE = "fan2_trace";
	public static final String ODU_HEADER_ID_MAIN_EEV = "main_eev";
	public static final String ODU_HEADER_ID_SUB_EEV = "sub_eev";
	public static final String ODU_HEADER_ID_OIL_EQ_EEV = "oil_eq_eev";
	public static final String ODU_HEADER_ID_SC_EEV = "sc_eev";
	public static final String ODU_HEADER_ID_VI_EEV1 = "vi_eev1";
	public static final String ODU_HEADER_ID_VI_EEV2 = "vi_eev2";
	public static final String ODU_HEADER_ID_FAN2_TARGET = "fan2_target"; // from mini4

	public static final String ODU_HEADER_ID_TVI_EEV = "TXT_TVI_EEV";
	public static final String ODU_HEADER_ID_LB_EEV = "TXT_LB_EEV";
	
	// ODU::Do not show
	public static final String ODU_HEADER_ID_FAN_ERROR = "fan_error";
	public static final String ODU_HEADER_ID_INV_ERROR = "inv_error";

	// ODU::Sensors
	public static final String ODU_HEADER_ID_AIR_TEMP = "air_temp";
	public static final String ODU_HEADER_ID_SUCTION_TEMP = "suction_temp";
	public static final String ODU_HEADER_ID_CONDENSING_TEMP = "condensing_temp";
	public static final String ODU_HEADER_ID_EVAPORATION_TEMP = "evaporating_temp";
	public static final String ODU_HEADER_ID_INV1_DISCHARGE_TEMP = "inv1_discharge_temp";
	public static final String ODU_HEADER_ID_INV2_DISCHARGE_TEMP = "inv2_discharge_temp";
	public static final String ODU_HEADER_ID_HEAT_EXCHANGER_TEMP = "heat_exchanger_temp";
	public static final String ODU_HEADER_ID_HEAT_EXCHANGER_UP_TEMP = "heat_exchanger_up_temp";
	public static final String ODU_HEADER_ID_SC_PIPE_IN_TEMP = "sc_pipe_in_temp";
	public static final String ODU_HEADER_ID_HEAT_EXCHANGER_DOWN_TEMP = "heat_exchanger_down_temp";
	public static final String ODU_HEADER_ID_SC_PIPE_OUT_TEMP = "sc_pipe_out_temp";
	public static final String ODU_HEADER_ID_SC_PIPE_LIQUID_TEMP = "sc_pipe_liquid_pipe_temp";
	public static final String ODU_HEADER_ID_INV1_IPM_TEMP = "inv1_ipm_temp";
	public static final String ODU_HEADER_ID_INV2_IPM_TEMP = "inv2_ipm_temp";
	public static final String ODU_HEADER_ID_FAN_HEATSINK_TEMP = "fan_heatsink_temp";

	public static final String ODU_HEADER_ID_SUCTION_TEMP_HEX = "TXT_SUCTION_TEMP_HEX"; // from mini4
	public static final String ODU_HEADER_ID_INV1_DSH_TRACE = "TXT_INV1_DSH_TRACE"; // from mini4
	public static final String ODU_HEADER_ID_SUCTION_TEMP_ACCUM = "TXT_SUCTION_TEMP_ACCUM"; // from mini4
	public static final String ODU_HEADER_ID_OUT_HUMIDITY = "TXT_OUT_HUMIDITY"; // from mini4

	public static final String ODU_HEADER_ID_TVI_IN_TEMP = "TXT_TVI_IN_TEMP";
	public static final String ODU_HEADER_ID_TVI_OUT_TEMP = "TXT_TVI_OUT_TEMP";
	public static final String ODU_HEADER_ID_FAN2_HEATSINK_TEMP = "TXT_FAN2_HEATSINK_TEMP";
	public static final String ODU_HEADER_ID_NOISE_LEVEL = "TXT_NOISE_LEVEL";
	public static final String ODU_HEADER_ID_INV1_DSH_TEMP = "TXT_INV1_DSH_TEMP";
	public static final String ODU_HEADER_ID_INV2_DSH_TEMP = "TXT_INV2_DSH_TEMP";
	public static final String ODU_HEADER_ID_LB_OUT_TEMP = "TXT_LB_OUT_TEMP";


	// ODU::Electric
	public static final String ODU_HEADER_ID_INV1_INPUT_CURRENT = "inv1_input_current";
	public static final String ODU_HEADER_ID_INV2_INPUT_CURRENT = "inv2_input_current";
	public static final String ODU_HEADER_ID_INV1_INPUT_VOLTAGE = "inv1_input_voltage";
	public static final String ODU_HEADER_ID_INV2_INPUT_VOLTAGE = "inv2_input_voltage";
	public static final String ODU_HEADER_ID_INV1_FREQUENCY_INPUT_VOLTAGE = "inv1_frequency_input_voltage";
	public static final String ODU_HEADER_ID_INV2_FREQUENCY_INPUT_VOLTAGE = "inv2_frequency_input_voltage";
	public static final String ODU_HEADER_ID_INV1_UP_CURRENT = "inv1_up_current";
	public static final String ODU_HEADER_ID_INV2_UP_CURRENT = "inv2_up_current";
	public static final String ODU_HEADER_ID_FAN1_UP_CURRENT = "fan1_up_current";
	public static final String ODU_HEADER_ID_FAN2_UP_CURRENT = "fan2_up_current";
	public static final String ODU_HEADER_ID_FAN_DC_LINK_VOLTAGE = "fan_dc_link_voltage";
	public static final String ODU_HEADER_ID_INV1_DC_LINK_VOLTAGE = "inv1_dc_link_voltage";
	public static final String ODU_HEADER_ID_INV2_DC_LINK_VOLTAGE = "inv2_dc_link_voltage";

	// ODU::Control info
	public static final String ODU_HEADER_ID_COMP_OVERLOAD = "comp_overload";
	public static final String ODU_HEADER_ID_COMP_LIMIT_CT = "comp_limit_ct";
	public static final String ODU_HEADER_ID_COMP_LIMIT_TEMP = "comp_limit_temp";
	public static final String ODU_HEADER_ID_COMP_LIMIT_VT = "comp_limit_vt";


	// IDU
	public static final String IDU_HEADER_ID_CAPACITY = "idu_capacity";
	public static final String IDU_HEADER_ID_MODE = "idu_mode";
	public static final String IDU_HEADER_ID_WIND = "idu_wind";
	public static final String IDU_HEADER_ID_EEV = "idu_eev";
	public static final String IDU_HEADER_ID_AIR_TEMP = "idu_air_temp";
	public static final String IDU_HEADER_ID_PIPE_IN_TEMP = "idu_pipe_in_temp";
	public static final String IDU_HEADER_ID_PIPE_OUT_TEMP = "idu_pipe_out_temp";
	public static final String IDU_HEADER_ID_SCSH = "idu_scsh";
	public static final String IDU_HEADER_ID_ADDITIONAL_INFO = "idu_additional_info";
	public static final String IDU_HEADER_ID_COMM_COUNT = "idu_comm_count";
	public static final String IDU_HEADER_ID_CENTRAL_CONTROL_ADDRESS = "idu_central_control_address";
	public static final String IDU_HEADER_ID_ERROR_NUMBER = "idu_error_number";
	public static final String IDU_HEADER_ID_TYPE = "idu_type";

}
