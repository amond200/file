package test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import common.IProtocolParserId;
import common.Utils;
import data.DataVO;
import data.Protocol;
import network.SerialReader;


public class SerialReaderTest implements IProtocolParserId{

	static byte[] txPageOk = {(byte)0x02,(byte)0x0E,(byte)0x02,(byte)0x00,(byte)0x00,(byte)0x00,
			(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x26};
	
	static byte[] txPageOk2 = {(byte)0x08,(byte)0x02,(byte)0x03,(byte)0x02,(byte)0x0E,(byte)0x02,(byte)0x00,(byte)0x00,(byte)0x00,
			(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x26,(byte)0x25,(byte)0x16,(byte)0x36};
	
	static byte[] txPageFail = {(byte)0x02,(byte)0x0E,(byte)0x02,(byte)0x00,(byte)0x00,(byte)0x00,
			(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x00,(byte)0x33};
	
	static byte[] txPageFail2 = {(byte)0x02};
	
	@Test
	public void test_makeCRC8() {
		byte crc8 = Utils.makeCRC8(txPageOk, txPageOk[1]-1);
		assertEquals(txPageOk[13], crc8);
	}
	
	@Test
	public void test_putParsing_ok() {
		SerialReader sr = new SerialReader(null, null);
		
		int ret = sr.putParsing(txPageOk2, txPageOk2.length);
		
		assertEquals(2, ret);
				
	}
	
	@Test
	public void test_putParsing_fail() {
		SerialReader sr = new SerialReader(null, null);
		
		int ret = sr.putParsing(txPageFail, txPageFail.length);
		
		assertEquals(-1, ret);
				
	}
	
	@Test
	public void test_putParsing_fail2() {
		SerialReader sr = new SerialReader(null, null);
		
		int ret = sr.putParsing(txPageFail2, txPageFail2.length);
		
		assertEquals(-1, ret);
				
	}
	
	@Test
	public void test_make_protocol() {
		Protocol protocol = new Protocol();
		
		List<DataVO> dataListForTest = new ArrayList<>();
		dataListForTest.add(new DataVO(TYPE_SYSTEM, 0, ODU_HEADER_ID_LOWPRESSURE_TARGET, 
				new int[]{3}, null, 120));	//0x78
		dataListForTest.add(new DataVO(TYPE_SYSTEM, 0, ODU_HEADER_ID_HIGHPRESSURE_TARGET, 
				new int[]{4}, null, 200));	//0xC8
		dataListForTest.add(new DataVO(TYPE_CYCLE, 0, ODU_HEADER_ID_INV1_TARGET, 
				new int[]{5,4}, null, 5000)); //4:0x13 5:0x88 // 4:19 5:136
		//10000111, 135, 0x87
		dataListForTest.add(new DataVO(TYPE_CYCLE, 0, ODU_HEADER_ID_COMP2_OIL_LEVEL, 
				new int[]{6}, new int[]{6,7}, 2)); 
		dataListForTest.add(new DataVO(TYPE_CYCLE, 0, ODU_HEADER_ID_COMP1_OIL_LEVEL, 
				new int[]{6}, new int[]{5}, 0));
		dataListForTest.add(new DataVO(TYPE_CYCLE, 0, ODU_HEADER_ID_HEX_VALVE, 
				new int[]{6}, new int[]{0,1,2}, 7));
		//10101010, 170, 0xAA
		dataListForTest.add(new DataVO(TYPE_CYCLE, 0, ODU_HEADER_ID_COMP1_OIL_LEVEL, 
				new int[]{8}, new int[]{3,4,5,6,7}, 21));
		dataListForTest.add(new DataVO(TYPE_CYCLE, 0, ODU_HEADER_ID_COMP2_OIL_LEVEL, 
				new int[]{8}, new int[]{0,1,2}, 2)); 
//		protocol.setDataList(dataListForTest);
		
		assertEquals(120, protocol.getData(TYPE_SYSTEM, 3));
		assertEquals(200, protocol.getData(TYPE_SYSTEM, 4));
		
		assertEquals(Utils.byteToUnsignedInt((byte)0x88), protocol.getData(TYPE_CYCLE, 5));
		assertEquals(Utils.byteToUnsignedInt((byte)0x13), protocol.getData(TYPE_CYCLE, 4));
		
		assertEquals(135, protocol.getData(Protocol.TYPE_CYCLE, 6));
		assertEquals(170, protocol.getData(Protocol.TYPE_CYCLE, 8));

	}
	
	@Test
	public void test_make_protocol2() {
		Protocol protocol = new Protocol();
		
		List<DataVO> dataListForTest = new ArrayList<>();
		dataListForTest.add(new DataVO(TYPE_CYCLE, 0, ODU_HEADER_ID_LOWPRESSURE_TARGET, 
				new int[]{3}, null, 120));	//0x78
		dataListForTest.add(new DataVO(TYPE_CYCLE, 0, ODU_HEADER_ID_HIGHPRESSURE_TARGET, 
				new int[]{7}, null, 200));	//0xC8
		dataListForTest.add(new DataVO(TYPE_CYCLE, 0, ODU_HEADER_ID_INV1_TARGET, 
				new int[]{5,4}, null, 5000)); //4:0x13 5:0x88 // 4:19 5:136
		//10000111, 135, 0x87
		dataListForTest.add(new DataVO(TYPE_CYCLE, 0, ODU_HEADER_ID_COMP2_OIL_LEVEL, 
				new int[]{6}, new int[]{6,7}, 2)); 
		dataListForTest.add(new DataVO(TYPE_CYCLE, 0, ODU_HEADER_ID_COMP1_OIL_LEVEL, 
				new int[]{6}, new int[]{5}, 0));
		dataListForTest.add(new DataVO(TYPE_CYCLE, 0, ODU_HEADER_ID_HEX_VALVE, 
				new int[]{6}, new int[]{0,1,2}, 7));
		//10101010, 170, 0xAA
		dataListForTest.add(new DataVO(TYPE_CYCLE, 0, ODU_HEADER_ID_COMP1_OIL_LEVEL, 
				new int[]{8}, new int[]{3,4,5,6,7}, 21));
		dataListForTest.add(new DataVO(TYPE_CYCLE, 0, ODU_HEADER_ID_COMP2_OIL_LEVEL, 
				new int[]{8}, new int[]{0,1,2}, 2)); 
//		protocol.setDataList(dataListForTest);
		
		byte[] ret = protocol.makeCycleInfoPacket(0);
		System.out.println("ret: " + Utils.byteArrayToHexString(ret));
		
		assertEquals(Utils.byteToUnsignedInt((byte)0x78), Utils.byteToUnsignedInt((byte)ret[3]));
		assertEquals(Utils.byteToUnsignedInt((byte)0x13), Utils.byteToUnsignedInt((byte)ret[4]));
		assertEquals(Utils.byteToUnsignedInt((byte)0x88), Utils.byteToUnsignedInt((byte)ret[5]));
		assertEquals(Utils.byteToUnsignedInt((byte)0x87), Utils.byteToUnsignedInt((byte)ret[6]));
		assertEquals(Utils.byteToUnsignedInt((byte)0xC8), Utils.byteToUnsignedInt((byte)ret[7]));
		assertEquals(Utils.byteToUnsignedInt((byte)0xAA), Utils.byteToUnsignedInt((byte)ret[8]));
		
	}
	
	
}
