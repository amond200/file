package network;

import java.io.OutputStream;
import java.util.List;

import common.Utils;
import controller.SerialController;
import data.ProtocolModel;


public class SerialWriter implements Runnable {
	private OutputStream mOutStream;
	private SerialController mController;

	public SerialWriter(OutputStream out, SerialController controller) {
		this.mOutStream = out;
		this.mController = controller;
	}

	public void run() {

		Utils.printLog(Utils.LogType.INFO, "txRun: " + mController.getSendFlag() + " / txType: " + mController.getTxHeaderType());

		while(mController.getSendFlag()){
			try {
//				System.out.println(mController.getProtocol().getProtocolList());
				List<ProtocolModel> sendList = mController.getProtocol().getSendProtocolList(mController.getTxHeaderType());
//				System.out.println("headerType: " + mController.getTxHeaderType() + " / sendList size: " + sendList.size());
				for (ProtocolModel item : sendList) {
					byte txData[] = item.makePacket();
					if (txData != null && txData.length > 0) {
						this.mOutStream.write(txData, 0, txData.length);  
						mController.updateTxPacketCount();
						Utils.printLog(Utils.LogType.ERR, "[DATA_TX] txType: " + mController.getTxHeaderType() + " / size: " + txData.length);
						Utils.printLog(Utils.LogType.ERR,"[DATA_TX] data: " + Utils.byteArrayToHexString(txData));
						Thread.sleep(100);
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
				mController.setSendFlag(false);
			}
		}

	}



}
