package network;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import common.Utils;
import controller.SerialController;
import gnu.io.CommPort;
import gnu.io.CommPortIdentifier;
import gnu.io.SerialPort;

public class Serial {

	SerialPort serialPort = null;
	SerialController serialController;
	 
	public Serial(SerialController controller) {
		super();
		serialController = controller;
	}

	public void connect(String portName, int baudRate) throws Exception {
		CommPortIdentifier portIdentifier = CommPortIdentifier.getPortIdentifier(portName);
		if (portIdentifier.isCurrentlyOwned()) {
			Utils.printLog(Utils.LogType.ERR, "Error: Port is currently in use");
		} else {
			CommPort commPort = portIdentifier.open(this.getClass().getName(), 2000);

			if (commPort instanceof SerialPort) {
				serialPort = (SerialPort) commPort;
				serialPort.setSerialPortParams(baudRate, SerialPort.DATABITS_8, SerialPort.STOPBITS_1,
						SerialPort.PARITY_NONE);

				InputStream in = serialPort.getInputStream();
				(new Thread(new SerialReader(in, serialController))).start();
				OutputStream out = serialPort.getOutputStream();
				(new Thread(new SerialWriter(out, serialController))).start();

			} else {
				Utils.printLog(Utils.LogType.ERR, "Error: Only serial ports are handled by this example.");
			}
		}
	}	
	
	public void write()throws Exception {
		if (serialPort != null) {
			OutputStream out = serialPort.getOutputStream();
			(new Thread(new SerialWriter(out, serialController))).start();
		} else {
			Utils.printLog(Utils.LogType.ERR, "Error: serialPort is null");
		}
	}

	public synchronized void disconnect() {	// TODO 
		if (serialPort != null) {
			serialPort.close(); //close serial port
			
			try {
				// close the i/o streams.
				InputStream in = serialPort.getInputStream();
				OutputStream out = serialPort.getOutputStream();
				in.close();
				out.close();
			}
			catch (IOException ex) {
				// don't care
			}
			finally {
				// Close the port.
//				serialPort.removeEventListener();
//				serialPort.close();

				
			}
		}
		Utils.printLog(Utils.LogType.INFO, "disconnect..");
	}
}
