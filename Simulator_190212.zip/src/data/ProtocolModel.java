package data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import common.IProtocolParserId;
import common.Utils;

public class ProtocolModel implements IProtocolParserId {

	public static final int EMPTY_DATA = 0;
	public static final String IG_TYPE_CRC8 = "crc8";
	public static final String IG_TYPE_CRC16 = "crc16";
	public static final String IG_TYPE_CHECKSUM = "checksum";

	public String pageName = null;	// primary key
	public int pageCount;
	public int pageSize;
	public String integrityType = null;
	public int rxHeaderId = -1;
	public List<DataVO> mData = new ArrayList<>();

	public ProtocolModel(String pageName, int pageCount, int pageSize, String igType, int rxHeaderId) {
		this.pageName = pageName;
		this.pageCount = pageCount;
		this.pageSize = pageSize;
		this.integrityType = igType;
		this.rxHeaderId = rxHeaderId;
		this.mData = new ArrayList<>();
	}

	public ProtocolModel(String pageName, int pageCount, int pageSize, String igType, int rxHeaderId, List<DataVO> data) {
		this.pageName = pageName;
		this.pageCount = pageCount;
		this.pageSize = pageSize;
		this.integrityType = igType;
		this.rxHeaderId = rxHeaderId;
		this.mData = data;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("***** ProtocolModel *****\n");
		sb.append("* name: " + this.pageName + "\n");
		sb.append("* integrityType: " + this.integrityType + "\n");
		sb.append("== Data == \n");
		for (DataVO dv : this.mData) {
			sb.append(dv.toString() + "\n");
		}
		sb.append("*************************\n");
		return sb.toString();
	}

	public byte[] makePacket(){
		if (integrityType == null) {
			return null;
		}
		// checksum
		if (integrityType.equalsIgnoreCase(IG_TYPE_CHECKSUM)) {
			byte[] buffer = new byte[pageSize];
			for (int i = 0; i < getDataLastIndex(); i++) {
				buffer[i] = (byte)getData(i);
			}
			setIntegrityTypeValue(buffer);
			return buffer;
		} 
		
		// crc
		byte[] buffer = new byte[pageSize];
		buffer[0] = 0x02;
		buffer[1] = (byte)pageSize;
		for (int i = 2; i < getDataLastIndex(); i++) {
			buffer[i] = (byte)getData(i);
		}
		setIntegrityTypeValue(buffer);
		return buffer;
	}


	public int getData(int position) {

		if (mData == null || mData.isEmpty()) {
			Utils.printLog(Utils.LogType.ERR, "dataList is null..");
			return EMPTY_DATA;
		}

		List<DataVO> bitDataList = new ArrayList<>();
		for (DataVO data : mData) {
			Utils.printLog(Utils.LogType.DEBUG, "data: " + data.toString());

			List<Integer> posArray = data.getPosByte();
			if (data.getPosBit() == null) {
				Utils.printLog(Utils.LogType.DEBUG, "byte check / posArray: " + posArray + " / position: " + position);
				if (posArray.contains(position)) {
					int r = getByteValue(position, data.getPosByte(), data.getIntValue());
					Utils.printLog(Utils.LogType.DEBUG, "data: " + data.toString() + " /r: " + r);
					return r;
				}
			} else {
				if (posArray.contains(position)) {
					bitDataList.add(data);
				}
			}

		}
		Utils.printLog(Utils.LogType.DEBUG, "mDataList: " + mData.size());
		Utils.printLog(Utils.LogType.DEBUG, "bitDataList: " + bitDataList.size());
		if (bitDataList.size() > 0) {
			return getBitValue(bitDataList);
		}
		return EMPTY_DATA;
	}

	private int getBitValue(List<DataVO> bitDataList) {
		List<Integer> onBitList = new ArrayList<>();
		for (DataVO item : bitDataList) {
			List<Integer> bitArray = item.getPosBit();
			for (int i = 0 ; i < bitArray.size() ; i++) {
				if ((((item.getIntValue() >> i) & 0x01) == 0)? false : true) {
					onBitList.add(bitArray.get(i));
				}
			}
		}
		Collections.sort(onBitList);

		int retVal = 0;
		for (Integer item : onBitList) {
			retVal += Math.pow(2, item);
		}
		Utils.printLog(Utils.LogType.DEBUG, "retVal: " + retVal);

		return retVal;
	}


	private static int getByteValue(int position, List<Integer> posByte, int value) {
		if (posByte == null || posByte.size() <= 0) {
			Utils.printLog(Utils.LogType.ERR, "error2");
			return EMPTY_DATA;
		}
		Utils.printLog(Utils.LogType.DEBUG, "position: " + position + " / posByte: " + posByte + " / value: " + value);

		if (posByte.size() == 1) {
			return value;
		} else {
			int index = posByte.indexOf(position);
			Utils.printLog(Utils.LogType.DEBUG, "index : " + index);
			if (index != -1) {
				int tmp = (value >> (8*index)) & 0xff;
				Utils.printLog(Utils.LogType.DEBUG, "tmp : " + tmp);
				return tmp;
			} else {
				Utils.printLog(Utils.LogType.ERR, "error3");
				return EMPTY_DATA;
			}
		}
	}


	public int getDataLastIndex() {
		if (IG_TYPE_CRC8.equalsIgnoreCase(integrityType)) {
			return pageSize - 1;
		} else if (IG_TYPE_CRC16.equalsIgnoreCase(integrityType)) {
			return pageSize - 2;
		} else if (IG_TYPE_CHECKSUM.equalsIgnoreCase(integrityType)) {
			return pageSize -1;
		} 
		return pageSize;
	}

	public boolean setIntegrityTypeValue(byte[] buffer) {
		if (IG_TYPE_CRC8.equalsIgnoreCase(integrityType)) {
			short crc8 = Utils.makeCRC8(buffer, pageSize-1);
			buffer[pageSize-1] = (byte) (crc8);
			return true;
		} else if (IG_TYPE_CRC16.equalsIgnoreCase(integrityType)) {
			short crc16 = Utils.makeCRC16(buffer, pageSize-2);
			buffer[pageSize-2] = (byte) (crc16 >> 8); 
			buffer[pageSize-1] = (byte) (crc16);
			return true;
		} else if (IG_TYPE_CHECKSUM.equalsIgnoreCase(integrityType)) {
			short checksum = Utils.makeChecksum(buffer);
			buffer[pageSize-1] = (byte)checksum;
			return true;
		} 
		return false;
	}

}
