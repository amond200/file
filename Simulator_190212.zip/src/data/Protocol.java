package data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import common.IProtocolParserId;
import common.Utils;
import sample_data.IMultiVSampleDataMaker;
import sample_data.ISingleMultiSampleDataMaker;
import sample_data.Mini4;
import sample_data.Pressure;
import sample_data.Super5;
import sample_data.Sync4;

public class Protocol implements IProtocolParserId {

	public static final int EMPTY_DATA = 0;

	private List<ProtocolModel> mProtocolList;
	public enum ParsingStatus {
		NONE, CONTINUE, FINISH
	}
	private StringBuilder mParsingText;
	private int mParsingCount = 0;
	public Protocol() {
		mProtocolList = new ArrayList<>();
		mParsingText = new StringBuilder();
	}

	public void setProtocolList(List<ProtocolModel> list) {
		this.mProtocolList = list;
	}

	public void addProtocolModel(ProtocolModel pm) {
		mProtocolList.add(pm);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		if (mProtocolList != null) {
			sb.append("===========<mProtocolList>===========\n");
			sb.append("mProtocolList.size: " + mProtocolList.size());
			for (ProtocolModel pm : mProtocolList) {
				sb.append(pm.toString());
			}
			sb.append("=====================================\n");
		}

		return sb.toString();
	}

	public boolean hasDuplicatePage(String pageName, int pageCount) {
		return getProtocolModel(pageName, pageCount) == null ? false : true;
	}

	public boolean hasDuplicateDataId(String pageName, int pageCount, String id) {

		ProtocolModel pm = getProtocolModel(pageName, pageCount);
		if (pm == null) {
			return false;
		}

		for (DataVO dv : pm.mData) {
			if (dv.getId().equalsIgnoreCase(id)) {
				return true;
			}
		}

		return false;
	}

	public boolean removeProtocolModel(String pageName, int pageCount) {
		ProtocolModel pm = getProtocolModel(pageName, pageCount);
		if (pm == null) {
			return false;
		}

		mProtocolList.remove(pm);
		return true;
	}

	public ProtocolModel getProtocolModel(String pageName, int pageCount) {
		for (ProtocolModel pm : mProtocolList) {
			if (pm.pageName.equalsIgnoreCase(pageName) && pm.pageCount == pageCount) {
				return pm;
			}
		}
		return null;
	}

	public List<ProtocolModel> getProtocolModelList(int rxHeaderType) {
		List<ProtocolModel> ret = new ArrayList<>(); 
		for (ProtocolModel pm : mProtocolList) {
			if (pm.rxHeaderId == rxHeaderType) {
				ret.add(pm);
			}
		}
		return ret;
	}

	public boolean addDataVO(String pageName, int pageCount, DataVO item) {
		ProtocolModel pm = getProtocolModel(pageName, pageCount);
		if (pm == null) {
			return false;
		}
		pm.mData.add(item);
		return true;
	}

	public boolean updateDataVO(String pageName, int pageCount, String id, Integer value, List<Integer> posByte, List<Integer> posBit) {
		ProtocolModel pm = getProtocolModel(pageName, pageCount);
		if (pm == null) {
			return false;
		}

		for (DataVO dv : pm.mData) {
			if (dv.getId().equalsIgnoreCase(id)) {
				dv.setIntValue(value);
				dv.setPosByte(posByte);
				dv.setPosBit(posBit);
				return true;
			}
		}
		return false;
	}

	public boolean removeDataVO(String pageName, int pageCount, String id) {
		ProtocolModel pm = getProtocolModel(pageName, pageCount);
		if (pm == null) {
			return false;
		}
		for (DataVO dv : pm.mData) {
			if (dv.getId().equalsIgnoreCase(id)) {
				pm.mData.remove(dv);
				return true;
			}
		}
		return false;
	}

	public List<ProtocolModel> getProtocolList() {
		return this.mProtocolList;
	}

	public List<DataVO> getDataList() {
		List<DataVO> dataList = new ArrayList<>();
		for (ProtocolModel pm : mProtocolList) {
			dataList.addAll(pm.mData);
		}
		return dataList;
	}

	//	public String parsing(String text){
	//		String parsingText = null;
	//		StringBuffer sb = new StringBuffer();
	//		if(text != null){
	//			sb.append(text.trim());
	//		}
	//		int start = sb.indexOf("[");
	//		if(start < 0){
	//			return null;
	//		}
	//		sb = sb.delete(0, start);
	//		int end = sb.indexOf("]");
	//		if(end < 0){
	//			return null;
	//		}
	//		parsingText = sb.substring(1, end);
	//		sb = sb.delete(0, end+1);
	//		return parsingText;
	//	}

	public ParsingStatus parsing(String text) {

		StringBuffer sb = new StringBuffer();
		if (text != null) {
			sb.append(text.trim());
		}

		int start = sb.indexOf("[");
		int end = sb.indexOf("]");

		if (mParsingCount == 0) {
			if (start < 0) {
				return ParsingStatus.NONE;
			}

			if (end < 0) {
				mParsingText.append(sb.substring(start+1, sb.length()));
				mParsingCount++;
				return ParsingStatus.CONTINUE;
			}

			if (start < end) {
				mParsingText.append(sb.substring(start+1, end));
				mParsingCount++;
				return ParsingStatus.FINISH;
			} else {
				return ParsingStatus.NONE;
			}
		} else if (mParsingCount > 0) {
			if (start < 0) {
				if (end < 0) {
					mParsingText.append(sb.toString());
					mParsingCount++;
					return ParsingStatus.CONTINUE;
				} else {
					mParsingText.append(sb.substring(0, end));
					mParsingCount++;
					return ParsingStatus.FINISH;
				}
			} else {
				mParsingText.setLength(0);	// clear
				mParsingCount = 0;
				if (end < 0) {
					mParsingText.append(sb.substring(start+1, sb.length()));
					mParsingCount++;
				} else {
					if (start < end) {
						mParsingText.append(sb.substring(start+1, end));
						mParsingCount++;
						return ParsingStatus.FINISH;
					} else {
						return ParsingStatus.NONE;
					}
				}
				return ParsingStatus.NONE;
			}
		}

		return ParsingStatus.NONE;

	}

	public int getParsingCount() {
		return mParsingCount;
	}

	public void setParsingCount(int count) {
		mParsingCount = count;
	}

	public String getParsingText() {
		if (mParsingText != null) {
			return mParsingText.toString();
		} 
		return null;
	}

	public void clearParsingText() {	// Test
		mParsingText.setLength(0);
	}

	// comp1_oil_level:0:0 -> <comp1_oil_level#0, 0>
	public Map<String, String> getVerificationMap(String parsingText) {
		//OLD LGMV : ODU1.SEC1.TXT_LOW_PRESSURE_TRACE:1222:UNIT_KPA,
		//NEW LGMV : comp1_oil_level:0:0,
		Map<String, String> returnMap = new HashMap<>();
		if (parsingText == null) {
			return returnMap;
		}
		String textArray[] = parsingText.split(",");
		for(int i = 0; i < textArray.length; i++){
			String dataArray[] = textArray[i].split(":");
			if (dataArray == null || dataArray.length < 3) {
				continue;
			}
			String id = dataArray[0].trim();
			String pageCount = dataArray[1].trim();
			String value = dataArray[2].trim();
			returnMap.put(id + "." + pageCount, value);
		}
		return returnMap;
	}

	public boolean updateData(String parsingText) {
		if (parsingText == null) {
			return false;
		}

		boolean ret = false;
		Map<String, String> returnMap = getVerificationMap(parsingText);
		if (returnMap.size() == 0) {
			return ret;
		}

		//		List<DataVO> tt = getDataList();
		//		System.out.println("getDataList size: " + tt.size());

		for(String key :returnMap.keySet()){
			String idCountInfo[] = key.split("\\.");
			if (idCountInfo == null || idCountInfo.length < 2) {
				continue;
			}
			String id = idCountInfo[0];
			int pageCount = Integer.parseInt(idCountInfo[1]);
			DataVO data = getDataVO(id, pageCount);
			//			System.out.println("id: " + id + " / pageCount: " + pageCount + " / data: " + data);

			if (data != null) {
				//				System.out.println("check: " + data.getHexValue().equalsIgnoreCase(returnMap.get(key)));
				data.setCheckValue((data.getHexValue().equalsIgnoreCase(returnMap.get(key)) ? DataVO.CHECK_SUCCESS:DataVO.CHECK_FAIL));
				ret = true;
			} 
		}

		return ret;
	}

	public DataVO getDataVO(String id, int pageCount) {
		for (DataVO item : getDataList()) {
			if (item.getId().equalsIgnoreCase(id) && item.getPageCount() == pageCount) {
				return item;
			}
		}
		return null;
	}

	public boolean makeDefaultData(String modelName) {

		if (modelName == null || modelName.trim().isEmpty()) {
			return false;
		}

		IMultiVSampleDataMaker multiVDataMaker = null;
		ISingleMultiSampleDataMaker singleMultiDataMaker = null; 
		int oduCnt = -1;
		int iduCnt = -1;
		int hruCnt = -1;

		boolean ret = false;
		switch (modelName.toLowerCase()) {
		case "super5":
			mProtocolList.clear();
			oduCnt = 1;
			iduCnt = 2;
			multiVDataMaker = new Super5(oduCnt, iduCnt);

			// System Info.
			mProtocolList.add(new ProtocolModel(TYPE_SYSTEM, 0, 57, "crc16", 0, multiVDataMaker.makeSystemData(TYPE_SYSTEM, 0)));
			// Cycle Info.
			for (int i = 0 ; i < oduCnt ; i++) {
				mProtocolList.add(new ProtocolModel(TYPE_CYCLE, i, 74, "crc16", 2, multiVDataMaker.makeCycleData(TYPE_CYCLE, i)));
				for (int PCBNUM = 0 ; PCBNUM < 2 ; PCBNUM++) {
					mProtocolList.add(new ProtocolModel("InvInfo", i, 30, "crc16", 2, multiVDataMaker.makeInvInfo("InvInfo", i, PCBNUM)));
					mProtocolList.add(new ProtocolModel("FanInfo", i, 30, "crc16", 2, multiVDataMaker.makeFanInfo("FanInfo", i, PCBNUM)));
				}
			}
			break;
		case "mini4":
			mProtocolList.clear();
			oduCnt = 1;
			iduCnt = 2;
			multiVDataMaker = new Mini4(oduCnt, iduCnt);

			// System Info.
			mProtocolList.add(new ProtocolModel(TYPE_SYSTEM, 0, 31, "crc8", 0, multiVDataMaker.makeSystemData(TYPE_SYSTEM, 0)));
			// Cycle Info.
			for (int i = 0 ; i < oduCnt ; i++) {
				mProtocolList.add(new ProtocolModel(TYPE_CYCLE, i, 67, "crc16", 2, multiVDataMaker.makeCycleData(TYPE_CYCLE, i)));
			}
			// Communication Count
			mProtocolList.add(new ProtocolModel(TYPE_COMM_COUNT, 0, iduCnt+4, "crc8", 2, multiVDataMaker.makeCommuncationCount(TYPE_COMM_COUNT, 0)));
			// IDU
			for (int i = 0 ; i < iduCnt ; i++) {
				mProtocolList.add(new ProtocolModel(TYPE_IDU, i, 17, "crc8", 2, multiVDataMaker.makeIduData(TYPE_IDU, i)));
			}
			// data (1ea/1page)
			mProtocolList.add(new ProtocolModel(TYPE_DEV_DATA, 0, 14, "crc8", 2, multiVDataMaker.makeDevData(TYPE_DEV_DATA, 0)));
			break;
		case "sync4":
			mProtocolList.clear();

			oduCnt = 2;
			iduCnt = 2;
			hruCnt = 2;
			multiVDataMaker = new Sync4(oduCnt, iduCnt, hruCnt);

			// System Info.
			mProtocolList.add(new ProtocolModel(TYPE_SYSTEM, 0, 31, "crc8", 0, multiVDataMaker.makeSystemData(TYPE_SYSTEM, 0)));
			// Cycle Info.
			for (int i = 0 ; i < oduCnt ; i++) {
				mProtocolList.add(new ProtocolModel(TYPE_CYCLE, i, 67, "crc16", 2, multiVDataMaker.makeCycleData(TYPE_CYCLE, i)));
			}
			// Communication Count
			mProtocolList.add(new ProtocolModel(TYPE_COMM_COUNT, 0, iduCnt+4, "crc8", 2, multiVDataMaker.makeCommuncationCount(TYPE_COMM_COUNT, 0)));
			// IDU
			for (int i = 0 ; i < iduCnt ; i++) {
				mProtocolList.add(new ProtocolModel(TYPE_IDU, i, 17, "crc8", 2, multiVDataMaker.makeIduData(TYPE_IDU, i)));
			}
			// data (1ea/1page)
			mProtocolList.add(new ProtocolModel(TYPE_DEV_DATA, 0, 14, "crc8", 2, multiVDataMaker.makeDevData(TYPE_DEV_DATA, 0)));
			break;
		case "pressure":
			mProtocolList.clear();
			oduCnt = 1;
			iduCnt = 1;
			singleMultiDataMaker = new Pressure(oduCnt, iduCnt);
			mProtocolList.add(new ProtocolModel("makeTxPage0", 0, 17, "checksum", 0, singleMultiDataMaker.makeTxPage0("makeTxPage0")));
			mProtocolList.add(new ProtocolModel("makeTxPage1", 0, 17, "checksum", 0, singleMultiDataMaker.makeTxPage1("makeTxPage1")));
			mProtocolList.add(new ProtocolModel("makeTxPage2", 0, 17, "checksum", 0, singleMultiDataMaker.makeTxPage2("makeTxPage2")));
			mProtocolList.add(new ProtocolModel("makeTxPage3", 0, 17, "checksum", 0, singleMultiDataMaker.makeTxPage3("makeTxPage3")));
			mProtocolList.add(new ProtocolModel("makeTxPage4", 0, 17, "checksum", 0, singleMultiDataMaker.makeTxPage4("makeTxPage4")));
			mProtocolList.add(new ProtocolModel("makeTxPage11", 0, 17, "checksum", 0, singleMultiDataMaker.makeTxPage11("makeTxPage11")));
			mProtocolList.add(new ProtocolModel("makeTxPage12", 0, 17, "checksum", 0, singleMultiDataMaker.makeTxPage12("makeTxPage12")));
			for (int i = 1; i <= iduCnt; i=i+2) {
				if (i % 2 == 0) {
					mProtocolList.add(new ProtocolModel("makeTxPageIdu", i, 17, "checksum", 0, singleMultiDataMaker.makeTxPageIdu("makeTxPageIdu", i, i+1)));
				} else {
					mProtocolList.add(new ProtocolModel("makeTxPageIdu", i, 17, "checksum", 0, singleMultiDataMaker.makeTxPageIdu("makeTxPageIdu", i, 0)));
				}
			}
			break;
		default:
			break;
		}

		if (mProtocolList.isEmpty() == false) {
			ret = true;
		}

		return ret;
	}

	//	public int makeSendProtocolList(int headerType) {
	//
	//		// init list
	//		if (mSendList == null) {
	//			mSendList = new ArrayList<>();
	//		} else {
	//			mSendList.clear();
	//		}
	//
	//		mSendList = getProtocolModelList(headerType);
	//		if (mSendList.isEmpty()) {
	//			ProtocolModel systemModel = getProtocolModel(TYPE_SYSTEM, 0);	// TODO
	//			if (systemModel == null) {
	//				return -1;
	//			} else {
	//				mSendList.add(systemModel);
	//			}
	//		}
	//		return mSendList.size();
	//	}

	public List<ProtocolModel> getSendProtocolList(int headerType) {

		List<ProtocolModel> sendList = getProtocolModelList(headerType);

		if (sendList.isEmpty()) {
			List<ProtocolModel> systemModels = getProtocolModelList(0);
			if (systemModels == null || systemModels.isEmpty()) {
				return sendList;
			} else {
				sendList.addAll(systemModels);
			}
		}
		return sendList;
	}

	//	public byte[] makePacket(int sendPacketIndex){
	//		if (mSendList == null) {
	//			return null;
	//		}
	//		ProtocolModel model = mSendList.get(sendPacketIndex);
	//		if (model == null) {
	//			return null;
	//		}
	//		byte[] buffer = new byte[model.pageSize];
	//		buffer[0] = 0x02;
	//		buffer[1] = (byte)model.pageSize;
	//		for (int i = 2; i < model.getDataLastIndex(); i++) {
	//			buffer[i] = (byte)getData(model.pageName, i);
	//		}
	//		model.setIntegrityTypeValue(buffer);
	//		return buffer;
	//	}

	//	public byte[] makePacket(int headerType){
	//		ProtocolModel model = getProtocolModelList(headerType);
	//		if (model == null) {
	//			model = getProtocolModel(TYPE_SYSTEM);
	//		}
	//		if (model == null) {
	//			return null;
	//		}
	//		byte[] buffer = new byte[model.size];
	//		buffer[0] = 0x02;
	//		buffer[1] = (byte)model.size;
	//		for (int i = 2; i < model.getDataLastIndex(); i++) {
	//			buffer[i] = (byte)getData(model.name, i);
	//		}
	//		model.setIntegrityTypeValue(buffer);
	//		return buffer;
	//	}

	//	public byte[] makeSystemInfoPacket(){
	//		ProtocolModel model = null;
	//		for (ProtocolModel pm : mProtocolList) {
	//			if (TYPE_SYSTEM.equalsIgnoreCase(pm.name)) {
	//				model = pm;
	//				break;
	//			}
	//		}
	//		byte[] buffer = new byte[model.size];
	//		buffer[0] = 0x02;
	//		buffer[1] = (byte)model.size;
	//		for (int i = 2; i < model.getDataLastIndex(); i++) {
	//			buffer[i] = (byte)getData(TYPE_SYSTEM, i);
	//		}		
	//		model.setIntegrityTypeValue(buffer);
	//		Utils.printLog(Utils.LogType.DEBUG, "makeSystemInfoPacket: " + Utils.byteArrayToHexString(buffer));
	//		return buffer;
	//	}

	public byte[] makeCycleInfoPacket(int oduNum){
		ProtocolModel model = null;
		for (ProtocolModel pm : mProtocolList) {
			if (TYPE_CYCLE.equalsIgnoreCase(pm.pageName)) {
				model = pm;
				break;
			}
		}
		byte[] buffer = new byte[model.pageSize];
		buffer[0] = 0x02;
		buffer[1] = (byte)model.pageSize;
		buffer[2] = (byte)(101+oduNum);
		for (int i = 3; i < model.getDataLastIndex(); i++) {
			buffer[i] = (byte)getData(TYPE_CYCLE, i);
		}
		model.setIntegrityTypeValue(buffer);
		Utils.printLog(Utils.LogType.DEBUG, "makeCycleInfoPacket: " + Utils.byteArrayToHexString(buffer));
		return buffer;
	}

	public byte[] makeCommCountPacket(int iduNum){
		int size = iduNum+4;
		byte[] buffer = new byte[size];
		buffer[0] = 0x02;
		buffer[1] = (byte)(size);
		buffer[2] = (byte)105;
		for (int i = 3; i < size-1; i++) {
			buffer[i] = (byte)(i-3);
		}
		short crc8 = Utils.makeCRC8(buffer, size-1);
		buffer[size-1] = (byte) (crc8);
		return buffer;
	}

	public byte[] makeDataPacket(){
		int size = 14;
		byte[] buffer = new byte[size];
		buffer[0] = 0x02;
		buffer[1] = (byte)size;
		buffer[2] = (byte)107;
		for (int i = 3; i < size-1; i++) {
			buffer[i] = (byte)(i-3);
		}
		short crc8 = Utils.makeCRC8(buffer, size-1);
		buffer[size-1] = (byte) (crc8);
		return buffer;
	}

	public int getData(List<DataVO> dataList, int position) {

		if (dataList == null) {
			Utils.printLog(Utils.LogType.ERR, "dataList is null..");
			return EMPTY_DATA;
		}

		Utils.printLog(Utils.LogType.DEBUG, "getData / size: " + dataList.size());

		List<DataVO> bitDataList = new ArrayList<>();
		for (DataVO data : dataList) {
			Utils.printLog(Utils.LogType.DEBUG, "data: " + data.toString());

			List<Integer> posArray = data.getPosByte();
			if (data.getPosBit() == null) {
				Utils.printLog(Utils.LogType.DEBUG, "byte check / posArray: " + posArray + " / position: " + position);
				if (posArray.contains(position)) {
					int ret = getByteValue(position, data.getPosByte(), data.getIntValue());
					Utils.printLog(Utils.LogType.DEBUG, "data: " + data.toString() + " / ret: " + ret);
					return ret;
				}
			} else {
				if (posArray.contains(position)) {
					bitDataList.add(data);
				}
			}

		}
		Utils.printLog(Utils.LogType.DEBUG, "mDataList: " + dataList.size());
		Utils.printLog(Utils.LogType.DEBUG, "bitDataList: " + bitDataList.size());
		if (bitDataList.size() > 0) {
			return getBitValue(bitDataList);
		}
		return EMPTY_DATA;
	}

	public int getData(String pageType, int position) {

		List<DataVO> dataList = null;
		for (ProtocolModel pm : mProtocolList) {
			Utils.printLog(Utils.LogType.DEBUG, "getData / pageType: " + pageType + " / pm: " + pm.pageName + " / c: " + (pm.pageName.equalsIgnoreCase(pageType)));
			if (pm.pageName.equalsIgnoreCase(pageType)) {
				dataList = pm.mData;
				break;
			}
		}

		if (dataList == null) {
			Utils.printLog(Utils.LogType.ERR, "dataList is null..");
			return EMPTY_DATA;
		}

		Utils.printLog(Utils.LogType.DEBUG, "getData / pageType: " + pageType + " / size: " + dataList.size());

		List<DataVO> bitDataList = new ArrayList<>();
		for (DataVO data : dataList) {
			Utils.printLog(Utils.LogType.DEBUG, "data: " + data.toString());

			List<Integer> posArray = data.getPosByte();
			if (data.getPosBit() == null) {
				Utils.printLog(Utils.LogType.DEBUG, "byte check / posArray: " + posArray + " / position: " + position);
				if (posArray.contains(position)) {
					int r = getByteValue(position, data.getPosByte(), data.getIntValue());
					Utils.printLog(Utils.LogType.DEBUG, "data: " + data.toString() + " /r: " + r);
					return r;
				}
			} else {
				if (posArray.contains(position)) {
					bitDataList.add(data);
				}
			}

		}
		Utils.printLog(Utils.LogType.DEBUG, "mDataList: " + dataList.size());
		Utils.printLog(Utils.LogType.DEBUG, "bitDataList: " + bitDataList.size());
		if (bitDataList.size() > 0) {
			return getBitValue(bitDataList);
		}
		return EMPTY_DATA;
	}

	private int getBitValue(List<DataVO> bitDataList) {
		List<Integer> onBitList = new ArrayList<>();
		for (DataVO item : bitDataList) {
			List<Integer> bitArray = item.getPosBit();
			for (int i = 0 ; i < bitArray.size() ; i++) {
				if ((((item.getIntValue() >> i) & 0x01) == 0)? false : true) {
					onBitList.add(bitArray.get(i));
				}
			}
		}
		Collections.sort(onBitList);

		int retVal = 0;
		for (Integer item : onBitList) {
			retVal += Math.pow(2, item);
		}
		Utils.printLog(Utils.LogType.DEBUG, "retVal: " + retVal);

		return retVal;
	}


	private int getByteValue(int position, List<Integer> posByte, int value) {
		if (posByte == null || posByte.size() <= 0) {
			Utils.printLog(Utils.LogType.ERR, "error2");
			return EMPTY_DATA;
		}
		Utils.printLog(Utils.LogType.DEBUG, "position: " + position + " / posByte: " + posByte + " / value: " + value);

		if (posByte.size() == 1) {
			return value;
		} else {
			Collections.reverse(posByte);
			int index = posByte.indexOf(position);
			Utils.printLog(Utils.LogType.DEBUG, "index : " + index);
			if (index != -1) {
				int tmp = (value >> (8*index)) & 0xff;
				Utils.printLog(Utils.LogType.DEBUG, "tmp : " + tmp);
				return tmp;
			} else {
				Utils.printLog(Utils.LogType.ERR, "error3");
				return EMPTY_DATA;
			}
		}
	}

}

