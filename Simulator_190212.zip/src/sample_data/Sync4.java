package sample_data;

import java.util.ArrayList;
import java.util.List;

import common.IProtocolParserId;
import data.DataVO;

public class Sync4 implements IMultiVSampleDataMaker, IProtocolParserId{

	int mOduCnt;
	int mIduCnt;
	int mHruCnt;

	public Sync4(int oduCnt, int iduCnt, int hruCnt) {
		this.mOduCnt = oduCnt;
		this.mIduCnt = iduCnt;
		this.mHruCnt = hruCnt;
	}

	public List<DataVO> makeSystemData(String pageName, int pageCount) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, pageCount, SYSTEM_INFO_PAGE_NO, new int[]{2}, null, 100)); 
		dataList.add(new DataVO(pageName, pageCount, SYSTEM_INFO_PRODUCT_TYPE, new int[]{3}, null, 30));
		dataList.add(new DataVO(pageName, pageCount, SYSTEM_INFO_TOTAL_IDU_NUM, new int[]{28}, null, mIduCnt));
		dataList.add(new DataVO(pageName, pageCount, SYSTEM_INFO_TOTAL_HRU_NUM, new int[]{29}, null, mHruCnt));
		return dataList;
	}

	public List<DataVO> makeCycleData(String pageName, int pageCount) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, pageCount, CYCLE_PAGE_NO, new int[]{2}, null, 101+pageCount));

		dataList.add(new DataVO(pageName, pageCount, DEFAULT_HEADER_ID_ERROR_UNIT_NUMBER, new int[]{3}, new int[]{2,3,4}, 1)); 
		dataList.add(new DataVO(pageName, pageCount, DEFAULT_HEADER_ID_OPER_MODE, new int[]{3}, new int[]{0,1}, 1));

		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_INV1_TARGET, new int[]{4}, null, 4));
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_INV1_TRACE, new int[]{5}, null, 5));
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_INV2_TARGET, new int[]{6}, null, 6));
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_INV2_TRACE, new int[]{7}, null, 7));
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_FAN1_TARGET, new int[]{8}, null, 8));
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_FAN1_TRACE, new int[]{9}, null, 9));
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_FAN2_TRACE, new int[]{10}, null, 10));
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_HIGHPRESSURE_TARGET, new int[]{11}, null, 11));
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_LOWPRESSURE_TARGET, new int[]{12}, null, 12));
		dataList.add(new DataVO(pageName, pageCount,DEFAULT_HEADER_ID_ERROR_NUMBER, new int[]{13}, null, 13));
		// 14 목표 흡입과열도 혹은 목표 토출온도							
		// 15 목표 과냉각도 과열도							
		// 16 적설 AD 값							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_PORT_4WAY, new int[]{17}, new int[]{7}, 0));
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_PORT_RECEIVER_OUT, new int[]{17}, new int[]{6}, 0));
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_PORT_RECEIVER_IN, new int[]{17}, new int[]{5}, 0));
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_PORT_ACCUM_VALVE, new int[]{17}, new int[]{4}, 0));
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_PORT_INV2_PREHEAT, new int[]{17}, new int[]{3}, 1));
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_PORT_INV_PREHEAT, new int[]{17}, new int[]{2}, 1));
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_HEX_VALVE, new int[]{17}, new int[]{1}, 1));
		// 17(0) 균유 밸브

		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_PORT_HEX_LOW_VALVE, new int[]{18}, new int[]{4}, 0));
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_PORT_HEX_HIGH_VALVE, new int[]{18}, new int[]{3}, 1));
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_SUCTION_VALVE, new int[]{18}, new int[]{0}, 0));

		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_COMP2_OIL_LEVEL, new int[]{19}, new int[]{1}, 0));
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_COMP1_OIL_LEVEL, new int[]{19}, new int[]{0}, 1));

		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_MAIN_EEV, new int[]{20}, null, 20));	//20	(main1 EEV 개도)/8
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_SUB_EEV, new int[]{21}, null, 21));	//21	(Main2 EEV 개도) / 8
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_SC_EEV, new int[]{22}, null, 22));	//22	((과냉각 EEV 개도)/8							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_VI_EEV1, new int[]{23}, null, 23));	//23	VI EEV1 / 8							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_VI_EEV2, new int[]{24}, null, 24));	//24	VI EEV2 / 8							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_OIL_EQ_EEV, new int[]{25}, null, 25));	//25	Oil EQ EEV / 8	

		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_AIR_TEMP, new int[]{26}, null, 26));	//26	공기온도 ad 값							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_HIGHPRESSURE_TRACE, new int[]{27}, null, 27));	//27	현재 고압 ad 값							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_LOWPRESSURE_TRACE, new int[]{28}, null, 28));	//28	현재 저압 ad 값							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_SUCTION_TEMP, new int[]{29}, null, 29));	//29	흡입온도 ad 값							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_INV1_DISCHARGE_TEMP, new int[]{30}, null, 30));	//30	Comp1 토출온도 ad 값							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_INV2_DISCHARGE_TEMP, new int[]{31}, null, 31));	//31	Comp2 토출온도 ad 값
		//32 reserved							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_HEAT_EXCHANGER_TEMP, new int[]{33}, null, 33));	//33	열교환기 온도 ad 값							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_HEAT_EXCHANGER_UP_TEMP, new int[]{34}, null, 34));	//34	열교환기 상부 온도 ad값							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_HEAT_EXCHANGER_DOWN_TEMP, new int[]{35}, null, 35));	//35	열교환기 하부 온도 ad값							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_SC_PIPE_IN_TEMP, new int[]{36}, null, 36));	//36	과냉각기 입구 온도 ad 값							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_SC_PIPE_OUT_TEMP, new int[]{37}, null, 37));	//37	과냉각 출구 온도 ad값							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_SC_PIPE_LIQUID_TEMP, new int[]{38}, null, 38));	//38	액관온도 ad 값							
		//39	실내 배관입구 평균 온도 ad값	
		//40 reserved
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_INV_ERROR, new int[]{41}, new int[]{6,7}, 1)); //41(7,6)	Inv error정보(01:inv 1, 10:inv 2)		
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_FAN_ERROR, new int[]{41}, new int[]{4,5}, 0)); //41(5,4)	Fan error정보(01:fan 1, 10:fan 2)
		//41(3) PFC	동작2
		//41(2) PFC	동작1
		//41(1) Power Relay2
		//41(0) Power Relay1

		//42(7) Fan과부하1
		//42(3) Ipm 제한2
		//42(2) Ipm 제한1
		//42(1) COMP과부하2
		//42(0) COMP과부하1

		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_INV1_INPUT_CURRENT, new int[]{43}, null, 43));	//43	inverter1 입력전류 * 5							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_INV1_INPUT_VOLTAGE, new int[]{44}, null, 44));	//44	inverter1 입력전압 / 5							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_INV2_INPUT_CURRENT, new int[]{45}, null, 45));	//45	inverter2 입력전류 * 5							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_INV2_INPUT_VOLTAGE, new int[]{46}, null, 46));	//46	inverter2 입력전압 / 5							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_INV1_FREQUENCY_INPUT_VOLTAGE, new int[]{47}, null, 47));	//47	inv1 input power 주파수						
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_INV2_FREQUENCY_INPUT_VOLTAGE, new int[]{48}, null, 48));	//48	inv2 input power 주파수
		//49 reserved
		//50 reserved	
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_INV1_UP_CURRENT, new int[]{51}, null, 51));	//51	comp1 상전류 * 5							
		//52 reserved					
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_INV2_UP_CURRENT, new int[]{53}, null, 53));	//53	comp2 상전류 * 5							
		//54 reserved		
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_FAN1_UP_CURRENT, new int[]{55}, null, 55));	//55	fan 1 상전류 * 10							
		//56 reserved		
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_FAN2_UP_CURRENT, new int[]{57}, null, 57));	//57	fan 2 상전류 * 10							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_FAN_DC_LINK_VOLTAGE, new int[]{58}, null, 58));	//58	FAN DC link 전압 / 5							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_INV1_DC_LINK_VOLTAGE, new int[]{59}, null, 59));	//59	inv1 DC link 전압 / 5							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_INV2_DC_LINK_VOLTAGE, new int[]{60}, null, 60));	//60	inv2 DC link 전압 / 5							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_INV1_IPM_TEMP, new int[]{61}, null, 61));	//61	inv1 IPM 온도 센서 DEC 값							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_INV2_IPM_TEMP, new int[]{62}, null, 62));	//62	inv2 IPM 온도 센서 DEC 값							
		dataList.add(new DataVO(pageName, pageCount,ODU_HEADER_ID_FAN_HEATSINK_TEMP, new int[]{63}, null, 63));	//63	Fan HeatSink 온도 ad 값							
		//64(3) 입력전압제한2
		//64(2) 입력전압제한1
		//64(1) 입력전류제한2
		//64(0) 입력전류제한1
		return dataList;
	}

	public List<DataVO> makeCommuncationCount(String pageName, int pageCount) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, pageCount, "comm_count_page_number", new int[]{2}, null, 105));
		// IDU_HEADER_ID_COMM_COUNT
		return dataList;
	}

	public List<DataVO> makeDevData(String pageName, int pageCount) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, pageCount, "dev_count_page_number", new int[]{2}, null, 107));
		return dataList;
	}

	public List<DataVO> makeIduData(String pageName, int pageCount) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, pageCount , "idu_data_page_number", new int[]{2}, null, 106));
		dataList.add(new DataVO(pageName, pageCount, "idu_number", new int[]{3}, null, pageCount));
		
		//4(7) 	Lock	
		dataList.add(new DataVO(pageName, pageCount, IDU_HEADER_ID_TYPE, new int[]{4}, new int[]{0,1,2,3}, 1));	//4(0,1,2,3) 	IDU_TYPE
		//5(7) 	Master IDU	
		//5(4,5) indoor fan step
		dataList.add(new DataVO(pageName, pageCount, IDU_HEADER_ID_WIND, new int[]{5}, new int[]{4,5}, 1));
		//5(3) 	remocon on/off
		//5(2) 	thermo on/off
		//5(1) 	heating	
		//5(0) 	cooling
		dataList.add(new DataVO(pageName, pageCount, IDU_HEADER_ID_MODE, new int[]{5}, new int[]{0,1,2,3}, 5));
		
		dataList.add(new DataVO(pageName, pageCount, IDU_HEADER_ID_CAPACITY, new int[]{6}, null, 6));	//6		실내기 용량							
		//7		실내 LEV 개도 low 8 bit							
		//8		실내 LEV 개도 High 8 bit	
		dataList.add(new DataVO(pageName, pageCount, IDU_HEADER_ID_EEV, new int[]{7,8}, null, 65535));
		dataList.add(new DataVO(pageName, pageCount, IDU_HEADER_ID_AIR_TEMP, new int[]{9}, null, 9));	//9		실내 온도 ad 값(FAU는 본체온도)	
		dataList.add(new DataVO(pageName, pageCount, IDU_HEADER_ID_PIPE_IN_TEMP, new int[]{10}, null, 10));	//10	실내 배관 입구 온도 ad 값							
		dataList.add(new DataVO(pageName, pageCount, IDU_HEADER_ID_PIPE_OUT_TEMP, new int[]{11}, null, 11));	//11	실내 배관 출구 온도 ad 값							
		dataList.add(new DataVO(pageName, pageCount, IDU_HEADER_ID_ERROR_NUMBER, new int[]{12}, null, 12));	//12	Error Num.							
		dataList.add(new DataVO(pageName, pageCount, IDU_HEADER_ID_SCSH, new int[]{13}, null, 12));	//13	난방인 경우 과냉도/냉방인 경우 과열도							
		dataList.add(new DataVO(pageName, pageCount, IDU_HEADER_ID_CENTRAL_CONTROL_ADDRESS, new int[]{14}, null, 14));	//14	중앙제어주소	
		//15(7) 부호bit	
		//15(0~6)	실내기 목표SC/SH 값 (4시리즈실내기중, 일부모델)						
		return dataList;
	}

	@Override
	public List<DataVO> makeInvInfo(String pageName, int pageCount, int PCBNUM) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<DataVO> makeFanInfo(String pageName, int pageCount, int PCBNUM) {
		// TODO Auto-generated method stub
		return null;
	}

}
