package sample_data;

import java.util.ArrayList;
import java.util.List;

import data.DataVO;

public class Pressure implements ISingleMultiSampleDataMaker{
	
	int mOduCnt;
	int mIduCnt;
	
	public Pressure(int oduCnt, int iduCnt) {
		this.mOduCnt = oduCnt;
		this.mIduCnt = iduCnt;
	}

	// 100
	public List<DataVO> makeTxPage0(String pageName) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, 0, "m_Power_Relay", new int[]{0}, new int[]{0}, 0)); 
		dataList.add(new DataVO(pageName, 0, "m_FAN1_High", new int[]{0}, new int[]{1}, 1));
		dataList.add(new DataVO(pageName, 0, "m_EEV", new int[]{4}, null, 100));
		dataList.add(new DataVO(pageName, 0, pageName, new int[]{13}, null, 100));
		return dataList;
	}
	
	public List<DataVO> makeTxPage1(String pageName) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, 0, pageName, new int[]{13}, null, 101)); 
		return dataList;
	}
	
	public List<DataVO> makeTxPage2(String pageName) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, 0, pageName, new int[]{13}, null, 102)); 
		return dataList;
	}
	
	public List<DataVO> makeTxPage3(String pageName) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, 0, pageName, new int[]{13}, null, 103)); 
		return dataList;
	}
	
	public List<DataVO> makeTxPage4(String pageName) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, 0, pageName, new int[]{13}, null, 104)); 
		return dataList;
	}
	
	public List<DataVO> makeTxPage11(String pageName) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, 0, "steady_state_oper_mode", new int[]{2}, new int[]{0,1,2,3}, 0));	// 정상상태 운전모드
		dataList.add(new DataVO(pageName, 0, "idu_fan_set_value", new int[]{2}, new int[]{4,5,6,7}, 0));	// 설정 실내팬
		dataList.add(new DataVO(pageName, 0, "setting_temp", new int[]{3}, null, 0)); 	// 설정온도*2
		dataList.add(new DataVO(pageName, 0, pageName, new int[]{13}, null, 111)); 
		return dataList;
	}
	
	public List<DataVO> makeTxPage12(String pageName) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, 0, pageName, new int[]{13}, null, 112)); 
		return dataList;
	}
	
	public List<DataVO> makeTxPageIdu(String pageName, int iduNumber1, int iduNumber2) {
		List<DataVO> dataList = new ArrayList<>();
		if (iduNumber1 > 0) {
			dataList.add(new DataVO(pageName, iduNumber1, pageName+iduNumber1, new int[]{0}, null, iduNumber1));
			dataList.add(new DataVO(pageName, iduNumber1, "4bitFlag"+iduNumber1, new int[]{1}, new int[]{0,1,2,3}, 1));
		} 
		if (iduNumber2 > 0) {
			dataList.add(new DataVO(pageName, iduNumber1, pageName+iduNumber2, new int[]{8}, null, iduNumber2)); 
			dataList.add(new DataVO(pageName, iduNumber1, "4bitFlag"+iduNumber2, new int[]{9}, new int[]{0,1,2,3}, 1));
		}
		return dataList;
	}

}
