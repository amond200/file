package sample_data;

import java.util.ArrayList;
import java.util.List;

import common.IProtocolParserId;
import data.DataVO;

public class Super5 implements IMultiVSampleDataMaker, IProtocolParserId{

	int mOduCnt;
	int mIduCnt;

	public Super5(int oduCnt, int iduCnt) {
		this.mOduCnt = oduCnt;
		this.mIduCnt = iduCnt;
	}

	@Override
	public List<DataVO> makeSystemData(String pageName, int pageCount) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, pageCount, SYSTEM_INFO_ENTRY, new int[]{2}, null, 11)); 
		dataList.add(new DataVO(pageName, pageCount, SYSTEM_INFO_PAGE_NO, new int[]{3}, null, 100)); 
		dataList.add(new DataVO(pageName, pageCount, SYSTEM_INFO_PRODUCT_TYPE, new int[]{4}, null, 130));
		dataList.add(new DataVO(pageName, pageCount, SYSTEM_INFO_TOTAL_IDU_NUM, new int[]{53}, null, mIduCnt));
		return dataList;
	}

	@Override
	public List<DataVO> makeCycleData(String pageName, int pageCount) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, pageCount, CYCLE_INFO_ENTRY, new int[]{2}, null, 12));
		dataList.add(new DataVO(pageName, pageCount, CYCLE_PAGE_NO, new int[]{3}, null, 100+pageCount));
		//4	Error unit number		
		dataList.add(new DataVO(pageName, pageCount, DEFAULT_HEADER_ID_ERROR_UNIT_NUMBER, new int[]{4}, new int[]{2,3,4}, 1));
		//4 실외기 운전모드	
		dataList.add(new DataVO(pageName, pageCount, DEFAULT_HEADER_ID_OPER_MODE, new int[]{4}, new int[]{0,1}, 1));
		//5	Inv1 압축기 목표 주파수	
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_INV1_TARGET, new int[]{5}, null, 5));
		//6	Inv1 압축기 현재 주파수	
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_INV1_TRACE, new int[]{6}, null, 6));
		//7	Inv2 압축기 목표 주파수
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_INV2_TARGET, new int[]{7}, null, 7));
		//8	Inv2 압축기 현재 주파수							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_INV2_TRACE, new int[]{8}, null, 8));
		//9	inverter fan1 목표 RPM	
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_FAN1_TARGET, new int[]{9}, null, 9));
		//10 inverter fan1 현재 RPM	
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_FAN1_TRACE, new int[]{10}, null, 10));
		//11 inverter fan2 목표 RPM							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_FAN2_TARGET, new int[]{11}, null, 11));
		//12 inverter fan2 현재 RPM							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_FAN2_TARGET, new int[]{12}, null, 12));
		//13 ERROR 번호	
		dataList.add(new DataVO(pageName, pageCount, DEFAULT_HEADER_ID_ERROR_NUMBER, new int[]{13}, null, 13));
		//14 목표과열도							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_SH_TARGET, new int[]{14}, null, 14));
		//15 목표과냉도							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_SCSH_TARGET, new int[]{15}, null, 15)); // TODO
		//17 4way	
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_PORT_4WAY, new int[]{17}, new int[]{7}, 1));
		//17 4way2	
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_PORT_4WAY2, new int[]{17}, new int[]{6}, 0));
		//17 receiver out v/v	
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_PORT_RECEIVER_OUT, new int[]{17}, new int[]{5}, 1));
		//17 receiver in v/v	
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_PORT_RECEIVER_IN, new int[]{17}, new int[]{4}, 0));
		//17 Acc. Oil v/v
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_PORT_ACCUM_VALVE, new int[]{17}, new int[]{3}, 1));
		//17 inv2 예열
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_PORT_INV2_PREHEAT, new int[]{17}, new int[]{2}, 0));
		//17 inv1 예열
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_PORT_INV_PREHEAT, new int[]{17}, new int[]{1}, 1));
		//17 VI Suction
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_SUCTION_VALVE, new int[]{17}, new int[]{0}, 0));
		//18 Act. Oil v/v 2 	
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_OIL_CONTROL2, new int[]{18}, new int[]{7}, 1));
		//18 Act. Oil V/v 1 or Base Pan Heater
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_OIL_CONTROL1, new int[]{18}, new int[]{6}, 0));
		//18 가변PATH1	
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_HEX_VALVE, new int[]{18}, new int[]{4}, 1));
		//18 HEX Lo v/v	
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_PORT_HEX_LOW_VALVE, new int[]{18}, new int[]{3}, 0));
		//18 HEX Hi v/v	
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_PORT_HEX_HIGH_VALVE, new int[]{18}, new int[]{2}, 1));
		//18 균유v/v
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_OIL_BALANCE, new int[]{18}, new int[]{0}, 0));
		//19 dry contact1	
		//dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_OIL_BALANCE, new int[]{19}, new int[]{0}, 1));	// TODO : StringHex(!(port_Dry_Contact & port_Dry_Contact2))
		//19 dry contact2
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_DRY_CONTACT, new int[]{19}, new int[]{0}, 0));
		//19 Oil Sensor2 On/Off
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_COMP2_OIL_LEVEL, new int[]{19}, new int[]{0}, 1));
		//19 Oil Sensor1 On/Off
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_COMP1_OIL_LEVEL, new int[]{19}, new int[]{0}, 0));
		//20	main1 EEV 하위							
		//21	main1 EEV 상위 
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_MAIN_EEV, new int[]{20, 21}, null, 2021));
		//22	Main2 EEV 하위							
		//23	Main2 EEV 상위		
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_SUB_EEV, new int[]{22, 23}, null, 2223));
		//24	과냉각 EEV 하위							
		//25	과냉각 EEV 상위							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_SC_EEV, new int[]{24, 25}, null, 2425));
		//26	TVI or L/B EEV 하위							
		//27	TVI or L/B EEV 상위							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_TVI_EEV, new int[]{26, 27}, null, 2627));
		//28	VI EEV1 하위							
		//29	VI EEV1 상위							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_VI_EEV1, new int[]{28, 29}, null, 2829));
		//30	VI EEV2 하위							
		//31	VI EEV2 상위							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_VI_EEV2, new int[]{30, 31}, null, 3031));
		//32	목표 고압 AD 값 Low(10bit)							
		//33	목표 고압 AD 값 High(10bit)	
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_HIGHPRESSURE_TARGET, new int[]{32, 33}, null, 3233));
		//34	현재 고압 ad 값 Low(10bit)							
		//35	현재 고압 ad 값 High(10bit)							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_HIGHPRESSURE_TRACE, new int[]{34, 35}, null, 3435));
		//36	목표 저압 AD 값 Low(10bit)							
		//37	목표 저압 AD 값 High(10bit)							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_LOWPRESSURE_TARGET, new int[]{36, 37}, null, 3637));
		//38	현재 저압 ad 값 Low(10bit)							
		//39	현재 저압 ad 값 High(10bit)							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_LOWPRESSURE_TRACE, new int[]{38, 39}, null, 3839));
		//40	공기온도 ad 값 Low(10bit)							
		//41	공기온도 ad 값 High(10bit)							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_AIR_TEMP, new int[]{40, 41}, null, 4041));
		//42	흡입온도 ad 값 Low(10bit)							
		//43	흡입온도 ad 값 High(10bit)							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_SUCTION_TEMP, new int[]{42, 43}, null, 4243));
		//44	Inv1 압축기 토출온도 ad 값 Low(10bit)							
		//45	Inv1 압축기 토출온도 ad 값 High(10bit)	
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_SUCTION_TEMP, new int[]{44, 45}, null, 4445));
		//46	Inv2 압축기 토출온도 ad 값 Low(10bit)							
		//47	Inv2 압축기 토출온도 ad 값 High(10bit)							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_SUCTION_TEMP, new int[]{46, 47}, null, 4647));
		//48	열교환기 온도 ad 값 Low(10bit)							
		//49	열교환기 온도 ad 값 High(10bit)							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_SUCTION_TEMP, new int[]{48, 49}, null, 4849));
		//50	열교환기 상부 온도 ad값 Low(10bit)							
		//51	열교환기 상부 온도 ad값 High(10bit)							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_SUCTION_TEMP, new int[]{50, 51}, null, 5051));
		//52	열교환기 하부 온도 ad값 Low(10bit)							
		//53	열교환기 하부 온도 ad값 High(10bit)							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_SUCTION_TEMP, new int[]{52, 53}, null, 5253));
		//54	과냉각 입구 온도 ad 값 Low(10bit)							
		//55	과냉각 입구 온도 ad 값 High(10bit)							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_SUCTION_TEMP, new int[]{54, 55}, null, 5455));
		//56	과냉각 출구 온도 ad값 Low(10bit)							
		//57	과냉각 출구 온도 ad값 High(10bit)							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_SUCTION_TEMP, new int[]{56, 57}, null, 5657));
		//58	TVI 입구 온도 ad값 Low(10bit)							
		//59	TVI 입구 온도 ad값 High(10bit)							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_SUCTION_TEMP, new int[]{58, 59}, null, 5859));
		//60	TVI or L/B 출구 온도 ad값 Low(10bit)							
		//61	TVI or L/B 출구 온도 ad값 High(10bit)							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_SUCTION_TEMP, new int[]{60, 61}, null, 6061));
		//62	액관온도 ad 값 Low(10bit)							
		//63	액관온도 ad 값 High(10bit)							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_SUCTION_TEMP, new int[]{62, 63}, null, 6263));
		//64	외기 습도 Dec.							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_SUCTION_TEMP, new int[]{64}, null, 64));
		//65 Inv2 압축기 현재 주파수(0.1Hz)				
		dataList.add(new DataVO(pageName, pageCount, "inv1_trace_float", new int[]{65}, new int[]{4,5,6,7}, 4));
		//65 Inv1 압축기 현재 주파수(0.1Hz)			
		dataList.add(new DataVO(pageName, pageCount, "inv2_trace_float", new int[]{65}, new int[]{0,1,2,3}, 2));
		//66	소음레벨 ad값 Low							
		//67	소음레벨 ad값 High		
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_NOISE_LEVEL, new int[]{66, 67}, null, 6667));
		//68	Snow Piling AD값 Low(10bit)							
		//69	Snow Piling AD값 High(10bit)							
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_SNOW_DEEP, new int[]{68, 69}, null, 6869));
		//70	실내 배관입구 평균온도 AD값(8bit)
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_IDU_TEMP_WEIGHTED_AVG, new int[]{70}, null, 70));

		return dataList;
	}

	// INV 1, 2 / FAN 1,2 INFO
	@Override
	public List<DataVO> makeInvInfo(String pageName, int pageCount, int PCBNUM) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, pageCount, "default_entry_num", new int[]{2}, null, 13));
		int pageNum = 100+(pageCount*4)+PCBNUM;
		dataList.add(new DataVO(pageName, pageCount, "default_page_num", new int[]{3}, null, pageNum));
		//10	방열판 온도 (signed char 변수를 unsigned char로 type변환해서 송부)	
		dataList.add(new DataVO(pageName, pageCount, (PCBNUM == 0)?ODU_HEADER_ID_INV1_IPM_TEMP : ODU_HEADER_ID_INV2_IPM_TEMP, 
				new int[]{10}, null, 10));
		//11	입력 전류 (RMS * 5)	
		dataList.add(new DataVO(pageName, pageCount, (PCBNUM == 0)?ODU_HEADER_ID_INV1_INPUT_CURRENT : ODU_HEADER_ID_INV2_INPUT_CURRENT, 
				new int[]{11}, null, 11));
		//12	입력 전압 (RMS / 5)			
		dataList.add(new DataVO(pageName, pageCount, (PCBNUM == 0)?ODU_HEADER_ID_INV1_INPUT_VOLTAGE : ODU_HEADER_ID_INV2_INPUT_VOLTAGE, 
				new int[]{12}, null, 12));
		//13	상전류						
		dataList.add(new DataVO(pageName, pageCount, (PCBNUM == 0)? ODU_HEADER_ID_INV1_UP_CURRENT : ODU_HEADER_ID_INV2_UP_CURRENT, 
				new int[]{13}, null, 13));
		//17 예열	
		dataList.add(new DataVO(pageName, pageCount, "pre_heat", new int[]{17}, new int[]{4}, 0));
		//17 전압 제한
		dataList.add(new DataVO(pageName, pageCount, "inv_limit", new int[]{17}, new int[]{3}, 1));
		//17 Heatsink 온도 제한
		dataList.add(new DataVO(pageName, pageCount, "heatsink_temp_limit", new int[]{17}, new int[]{2}, 0));
		//17 입력전류 제한
		dataList.add(new DataVO(pageName, pageCount, "input_current_limit", new int[]{17}, new int[]{1}, 1));
		//17 과부하
		dataList.add(new DataVO(pageName, pageCount, "overload", new int[]{17}, new int[]{0}, 0));
		//18	입력 전원 주파수 (Hz)
		dataList.add(new DataVO(pageName, pageCount, (PCBNUM == 0)?ODU_HEADER_ID_INV1_FREQUENCY_INPUT_VOLTAGE : ODU_HEADER_ID_INV2_FREQUENCY_INPUT_VOLTAGE, 
				new int[]{18}, null, 18));
		//19	Inverter PCBA 구성							
		//20	SW P/No (상위)							
		//21	SW P/No (하위)							
		//22	SW Version(00부터 시작)	
		dataList.add(new DataVO(pageName, pageCount, "sw_version", new int[]{22}, null, 22));
		//23	Comp, Fan Motor 형명							
		//24	Stop Condition (개발자용, MV저장만)							
		//25	EEPROM SW P/No (상위)							
		//26	EEPROM SW P/No (하위)							
		//27	EEPROM Version(00부터 시작)							
		return dataList;
	}

	// INV 1, 2 / FAN 1,2 INFO
	@Override
	public List<DataVO> makeFanInfo(String pageName, int pageCount, int PCBNUM) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, pageCount, "default_entry_num", new int[]{2}, null, 13));
		int pageNum = 100+(pageCount*4)+PCBNUM+2;
		dataList.add(new DataVO(pageName, pageCount, "default_page_num", new int[]{3}, null, pageNum));
		//9	DC Link Voltage (VDC / 5)	
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_FAN_DC_LINK_VOLTAGE, new int[]{9}, null, 9));
		//10	방열판 온도 (signed char 변수를 unsigned char로 type변환해서 송부)	
		dataList.add(new DataVO(pageName, pageCount, (PCBNUM == 0)? ODU_HEADER_ID_FAN_HEATSINK_TEMP : ODU_HEADER_ID_FAN2_HEATSINK_TEMP, 
				new int[]{10}, null, 10));
		//13	상전류							
		dataList.add(new DataVO(pageName, pageCount, (PCBNUM == 0)? ODU_HEADER_ID_FAN1_UP_CURRENT : ODU_HEADER_ID_FAN2_UP_CURRENT, 
				new int[]{13}, null, 13));
		//14  Inv. PCB 0.1Hz 현재 주파수
		dataList.add(new DataVO(pageName, pageCount, "fan_float", new int[]{14}, new int[]{0,1,2,3}, 3));
		//17.4 예열	"전압
		dataList.add(new DataVO(pageName, pageCount, "Input_Voltage", new int[]{17}, new int[]{4}, 0));
		//17.3 제한"	"Heatsink
		dataList.add(new DataVO(pageName, pageCount, "IPM_Over", new int[]{17}, new int[]{3}, 1));
		//17.2 온도 제한"	"입력전류
		dataList.add(new DataVO(pageName, pageCount, "Input_Current", new int[]{17}, new int[]{2}, 0));
		//17.1 제한"
		dataList.add(new DataVO(pageName, pageCount, "COMP_Over", new int[]{17}, new int[]{1}, 3));
		//20	SW P/No (상위)							
		//21	SW P/No (하위)							
		//22	SW Version(00부터 시작)							
		dataList.add(new DataVO(pageName, pageCount, "sw_version", new int[]{22}, null, 22));
		return dataList;
	}

	@Override
	public List<DataVO> makeCommuncationCount(String pageName, int pageCount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<DataVO> makeDevData(String pageName, int pageCount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<DataVO> makeIduData(String pageName, int pageCount) {
		// TODO Auto-generated method stub
		return null;
	}

}
