package sample_data;

import java.util.List;

import data.DataVO;

public interface ISingleMultiSampleDataMaker {
	List<DataVO> makeTxPage0(String pageName);
	List<DataVO> makeTxPage1(String pageName);
	List<DataVO> makeTxPage2(String pageName);
	List<DataVO> makeTxPage3(String pageName);
	List<DataVO> makeTxPage4(String pageName);
	List<DataVO> makeTxPageIdu(String pageName, int iduNumber1, int iduNumber2);
	List<DataVO> makeTxPage11(String pageName);
	List<DataVO> makeTxPage12(String pageName);
}
