package sample_data;

import java.util.List;

import data.DataVO;

public interface IMultiVSampleDataMaker {
	List<DataVO> makeSystemData(String pageName, int pageCount);
	List<DataVO> makeCycleData(String pageName, int pageCount);
	List<DataVO> makeInvInfo(String pageName, int pageCount, int PCBNUM);
	List<DataVO> makeFanInfo(String pageName, int pageCount, int PCBNUM);
	List<DataVO> makeCommuncationCount(String pageName, int pageCount);
	List<DataVO> makeDevData(String pageName, int pageCount);
	List<DataVO> makeIduData(String pageName, int pageCount);
}
