package network;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

import controller.IClientController;

public class Client extends Thread{
	private Socket socket;
	private String hostIp;
	private int port;
	private boolean runThread;
	private InputStream is = null;
	private InputStreamReader isr = null;
	private OutputStream os = null;
	private OutputStreamWriter osw = null;
	private PrintWriter pw = null;
	private BufferedReader br = null;

	private IClientController controller;
	private int viewID;

	private static final long THREAD_WAIT_TIME = 10;
	private static final String SEND_MESSAGE = "[Command:Repuest,Period:2]";

	public Client(String hostIp, int port, IClientController controller, int clientID) {
		super();
		this.hostIp = hostIp;
		this.port = port;
		this.controller = controller;
		this.viewID = clientID;
	}

	public boolean isConnect() {
		if(socket != null) {
			return true;
		}else {
			return false;

		}
	}

	public boolean connect(){
		try {
			socket = new Socket(hostIp, port);
			is = socket.getInputStream();
			isr = new InputStreamReader(is);
			br = new BufferedReader(isr);
			os = socket.getOutputStream();
			osw = new OutputStreamWriter(os);
			pw = new PrintWriter(osw);
		} catch (Exception e) {
			e.printStackTrace();
			close();		
			socket  = null;
			return false;
		}
		return true;
	}


	public void run(){
		int reSendWaitTime = 2100;
		runThread = true;
		controller.printLog(viewID,"Client Start!!");
		while (runThread == true){
			try {
				if(reSendWaitTime > 2000){
					reSendWaitTime = 0;
					pw.write(SEND_MESSAGE);
					pw.flush();
					socket.getOutputStream().flush();
					controller.printLog(viewID,"send : "+ SEND_MESSAGE);
				}

				while(br.ready() == true){
					StringBuffer sb = new StringBuffer();
					char buffer[] = new char[2048];
					int readCount = 0;
					if((readCount=br.read(buffer, 0, 2048)) > 0){
						sb.append(buffer,0,readCount);
					}
					if(readCount > 0){
//						controller.printLog(viewID,"read ["+readCount+"] : " + sb.toString());
						controller.putParsing(viewID,sb.toString());
					}
				}
				if(pw.checkError() == true){
					close();
					socket  = null;
					controller.socketClose(viewID);
				}
			} catch (IOException e) {
				e.printStackTrace();
				close();
				socket  = null;
				controller.socketClose(viewID);
			}

			try {
				Thread.sleep(THREAD_WAIT_TIME);
				reSendWaitTime += THREAD_WAIT_TIME; 
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public void close(){
		runThread = false;
		if(os != null){
			try {
				os.close();
				os = null;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		if(is != null){
			try {
				is.close();
				is = null;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if(isr != null){
			try {
				isr.close();
				isr = null;
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		if(osw != null){
			try {
				osw.close();
				osw = null;
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		if(br != null){
			try {
				br.close();
				br = null;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if(pw != null){
			pw.close();
			pw = null;
		}
		if(socket != null){
			try {
				controller.printLog(viewID, "Client Close!");
				socket.close();
				socket = null;
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}
}