package network;

import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedList;

import common.Utils;
import controller.SerialController;

public class SerialReader implements Runnable {
	private InputStream mInStream;
	private SerialController mController;
	private LinkedList<Byte> mBufferQueue = new LinkedList<>();
		
	public SerialReader(InputStream in, SerialController controller) {
		this.mInStream = in;
		this.mController = controller;
		if (mBufferQueue == null) {
			mBufferQueue = new LinkedList<>();
		}
		mBufferQueue.clear();
	}

	public void run() {
		byte[] buffer = new byte[1024];
		int len = -1;
		try {
			while ((len = this.mInStream.read(buffer)) > -1) {
				if (len > 0) {
					Utils.printLog(Utils.LogType.DEBUG, "run: " + Utils.byteArrayToHexString(buffer, len));
					int ret = putParsing(buffer, len);
					if (ret != -1) {
						mController.setTxHeaderType(ret);
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	public int putParsing(byte[] readBuf, int size) {
		for (int i = 0 ; i< readBuf.length && i < size ; i++) {
			mBufferQueue.addLast(readBuf[i]);
		}
		
		int startIdx = 0;
		int sizeIdx = 1;
		int headerIdx = 2;
		int packetSize = 14;
		
		int headerValue = -1;
		
		while (mBufferQueue.size() > 0) {
			if (mBufferQueue.get(startIdx) != 2) {
				Utils.printLog(Utils.LogType.DEBUG, "removeFirst 1: " + mBufferQueue.get(startIdx));
				mBufferQueue.removeFirst();
                continue;
            }
				
			Utils.printLog(Utils.LogType.DEBUG, "size = " + mBufferQueue.size());
			if (mBufferQueue.size() <= sizeIdx) {
				break;
			}
				
			if (mBufferQueue.get(sizeIdx) != 14) {
				Utils.printLog(Utils.LogType.DEBUG, "removeFirst 2: " + mBufferQueue.get(sizeIdx));
				mBufferQueue.removeFirst();
                continue;
			}
			
			if (mBufferQueue.size() <= mBufferQueue.get(sizeIdx)) {
                break;
            }
            
			if (Utils.checkCRC8(Utils.convertToByte(mBufferQueue, 0, mBufferQueue.size() - 1), mBufferQueue.get(1)-1, mBufferQueue.get(packetSize-1))) {
				Utils.printLog(Utils.LogType.DEBUG, "ok : " + Utils.byteArrayToHexString(Utils.convertToByte(mBufferQueue, 0, mBufferQueue.size() - 1)));
				headerValue = mBufferQueue.get(headerIdx);
				Utils.printLog(Utils.LogType.DEBUG, "ok : " + headerValue);
				Utils.removeLinkedList(mBufferQueue, mBufferQueue.get(1));
				break;
			} else {
				mBufferQueue.removeFirst();
				continue;
			}
		}
		
		Utils.printLog(Utils.LogType.DEBUG, "remain: " + mBufferQueue);
		
		return headerValue;
		
	}
	
}
