package network;

import java.io.OutputStream;

import common.Utils;
import controller.SerialController;


public class SerialWriter implements Runnable {
	private OutputStream mOutStream;
	private SerialController mController;

	public SerialWriter(OutputStream out, SerialController controller) {
		this.mOutStream = out;
		this.mController = controller;
	}

	public void run() {

		Utils.printLog(Utils.LogType.INFO, "txRun: " + mController.getSendFlag() + " / txType: " + mController.getTxHeaderType());

		while(mController.getSendFlag()){
			try {
//				byte txData[] = null; //{(byte)0x00};
				
//				byte txData[] = mController.getProtocol().makePacket(mController.getTxHeaderType());
//				Utils.printLog(Utils.LogType.ERR, "[DATA_TX] txData.length: " + txData.length);
//				if (txData != null && txData.length > 0) {
//					this.mOutStream.write(txData, 0, txData.length);  
//					mController.updateTxPacketCount();
//					Utils.printLog(Utils.LogType.ERR, "[DATA_TX] txType: " + mController.getTxHeaderType() + " / size: " + txData.length);
//					Utils.printLog(Utils.LogType.ERR,"[DATA_TX] data: " + Utils.byteArrayToHexString(txData));
//					Thread.sleep(500);
//				}
				
				int sendPacketCnt = mController.getProtocol().makeSendProtocolList(mController.getTxHeaderType());
				Utils.printLog(Utils.LogType.INFO, "header type: " + mController.getTxHeaderType() + " / sendPacketCnt: " + sendPacketCnt);
				
				for (int i = 0 ; i < sendPacketCnt ; i++) {
					byte txData[] = mController.getProtocol().makePacket(i);
					Utils.printLog(Utils.LogType.INFO, "[DATA_TX] txData.length: " + txData.length);
					if (txData != null && txData.length > 0) {
						this.mOutStream.write(txData, 0, txData.length);  
						mController.updateTxPacketCount();
						Utils.printLog(Utils.LogType.DEBUG, "[DATA_TX] txType: " + mController.getTxHeaderType() + " / size: " + txData.length);
						Utils.printLog(Utils.LogType.DEBUG,"[DATA_TX] data: " + Utils.byteArrayToHexString(txData));
						Thread.sleep(500);
					}
				}
				
				
//				switch (mController.getTxHeaderType()) {
//				case 2:
//					txData = mController.getProtocol().makeCycleInfoPacket(0);
//					this.mOutStream.write(txData, 0, txData.length);
//
//					Thread.sleep(500);
//					txData = mController.getProtocol().makeCycleInfoPacket(1);
//					this.mOutStream.write(txData, 0, txData.length);
//
//					Thread.sleep(500);
//					txData = mController.getProtocol().makeCycleInfoPacket(2);
//					this.mOutStream.write(txData, 0, txData.length);
//
//					Thread.sleep(500);
//					txData = mController.getProtocol().makeCycleInfoPacket(3);
//					this.mOutStream.write(txData, 0, txData.length);
//
//					Thread.sleep(500);
//					txData = mController.getProtocol().makeCommCountPacket(10);
//					this.mOutStream.write(txData, 0, txData.length);
//
//					Thread.sleep(500);
//					txData = mController.getProtocol().makeDataPacket();
//					this.mOutStream.write(txData, 0, txData.length);
//					
//					mController.updateTxPacketCount();
//					
//					break;
//				default:
//					txData = mController.getProtocol().makeSystemInfoPacket();
//					this.mOutStream.write(txData, 0, txData.length);  
//					break;
//				}
//				Thread.sleep(500);

			} catch (Exception e) {
				e.printStackTrace();
				mController.setSendFlag(false);
			}
		}

	}



}
