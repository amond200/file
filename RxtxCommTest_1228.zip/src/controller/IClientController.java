package controller;

public interface IClientController {
	int VIEW_ID_LGMV 			= 0;

	void printLog(int modelID, String log);
	void putParsing(int viewID, String str);
	void socketClose(int clientID);
}
