package data;

import java.util.ArrayList;
import java.util.List;

import common.Utils;

public class DataVO { //implements Comparable<DataVO>{
	public static final String CHECK_NULL = "";
	public static final String CHECK_FAIL = "FAIL";
	public static final String CHECK_SUCCESS = "PASS";
	
	private String mId;
	private String mPageType;
	private List<Integer> mPosByte;
	private List<Integer> mPosBit;
	private int mValue;
	private String mCheck;
	
	@Override
	public String toString() {
		return "id: " + mId + " / pageType: " + mPageType + " / posByte: " + mPosByte + " / posBit: " + mPosBit + " / value: " + mValue;
	}
	
	public DataVO(String id, String pageType, List<Integer> bytePos, List<Integer> bitPos, int value) {
		super();
		this.mId = id;
		this.mPageType = pageType;
		this.mPosByte = bytePos;
		this.mPosBit = bitPos;
		this.mValue = value;
		this.mCheck = CHECK_NULL;
	}
	
	public DataVO(String id, String pageType, int[] bytePos, int[] bitPos, int value) {
		super();
		this.mId = id;
		this.mPageType = pageType;
		this.mPosByte = new ArrayList<>();
		if (bytePos != null && bytePos.length > 0) {
			for (int i = 0; i < bytePos.length ; i++) {
				this.mPosByte.add(bytePos[i]);
			}
		} else {
			this.mPosByte = null;
		}
		this.mPosBit = new ArrayList<>();
		if (bitPos != null && bitPos.length > 0) {
			for (int i = 0; i < bitPos.length ; i++) {
				this.mPosBit.add(bitPos[i]);
			}
		} else {
			this.mPosBit = null;
		}
		this.mValue = value;
		this.mCheck = CHECK_NULL;
	}
	
	public void setId(String id) {
		this.mId = id;
	}
	
	public String getId() {
		return mId;
	}
	public String getPageType() {
		return mPageType;
	}

	public List<Integer> getPosByte() {
		return mPosByte;
	}
	
	public void setPosByte(List<Integer> posByte) {
		this.mPosByte = posByte;
	}

	public List<Integer> getPosBit() {
		return mPosBit;
	}
	
	public void setPosBit(List<Integer> posBit) {
		this.mPosBit = posBit;
	}

	public int getIntValue() {
		return mValue;
	}
	
	public String getHexValue() {
		byte[] tmp = new byte[1];
		tmp[0] = (byte)mValue;
		return String.format("%X",Utils.byteToUnsignedInt(tmp[0]));
	}
	
	public String getCheckValue() {
		return mCheck;
	}
	
	public void setCheckValue(String check) {
		this.mCheck = check;
	}
	
	public void setValue(int value) {
		this.mValue = value;
	}

}