package data;

import java.util.ArrayList;
import java.util.List;

import common.IProtocolParserId;
import common.Utils;

public class ProtocolModel implements IProtocolParserId {

	public static final String IG_TYPE_CRC8 = "crc8";
	public static final String IG_TYPE_CRC16 = "crc16";
	public static final String IG_TYPE_CHECKSUM = "checksum";
	
	public int size;
	public String name = null;	// primary key
	public String integrityType = null;
	public int rxHeaderId = -1;
	public List<DataVO> data = new ArrayList<>();

	public ProtocolModel(String name, int size, String igType, int rxHeaderId) {
		this.name = name;
		this.size = size;
		this.integrityType = igType;
		this.rxHeaderId = rxHeaderId;
		this.data = new ArrayList<>();
	}
	
	public ProtocolModel(String name, int size, String igType, int rxHeaderId, List<DataVO> data) {
		this.name = name;
		this.size = size;
		this.integrityType = igType;
		this.rxHeaderId = rxHeaderId;
		this.data = data;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("***** ProtocolModel *****\n");
		sb.append("* name: " + this.name + "\n");
		sb.append("* integrityType: " + this.integrityType + "\n");
		sb.append("== Data == \n");
		for (DataVO dv : this.data) {
			sb.append(dv.toString() + "\n");
		}
		sb.append("*************************\n");
		return sb.toString();
	}

	public int getDataLastIndex() {
		if (IG_TYPE_CRC8.equals(integrityType)) {
			return size - 1;
		} else if (IG_TYPE_CRC16.equals(integrityType)) {
			return size - 2;
		} else if (IG_TYPE_CHECKSUM.equals(integrityType)) {
			return size;
		} 
		return size;
	}
	
	public boolean setIntegrityTypeValue(byte[] buffer) {
		if (IG_TYPE_CRC8.equals(integrityType)) {
			short crc8 = Utils.makeCRC8(buffer, size-1);
			buffer[size-1] = (byte) (crc8);
			return true;
		} else if (IG_TYPE_CRC16.equals(integrityType)) {
			short crc16 = Utils.makeCRC16(buffer, size-2);
			buffer[size-2] = (byte) (crc16 >> 8); 
			buffer[size-1] = (byte) (crc16);
			return true;
		} else if (IG_TYPE_CHECKSUM.equals(integrityType)) {
			return false;
		} 
		return false;
	}

}
