package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import common.ICommon;
import common.Utils;
import controller.SaveLoadController;
import controller.SerialController;
import controller.SocketCommController;
import data.DataVO;
import data.Protocol;
import data.ProtocolModel;
import javax.swing.border.LineBorder;

@SuppressWarnings("serial")
public class MainView extends JFrame implements ICommon {

	public enum InputCheck {
		SUCCESS, ERROR_TYPE, ERROR_ID, ERROR_VALUE, ERROR_BYTE_LOC, ERROR_BIT_LOC
	}

	private DefaultTableModel mProtocolTableModel;
	private JTable mProtocolTable;

	private DefaultTableModel mPageTableModel;
	private JTable mPageInfoTable;
	private static Object[] sPageTableColumns = { "Page name", "Size", "Integrity", "Rx header ID" };

	private Protocol mProtocol;
	private SerialController mSerialController;
	private SocketCommController mSocketCommController;
	private SaveLoadController mSaveLoadController;

	private JPanel mPanel;
	private JFrame mMainFrame;

	private JPanel mProtocolInfoPanel;

	private JTextField mPortNumEditView;
	private JTextField mBaudRateEditView;

	private JTextField mServerIpEditView;
	private JTextField mServerPortEditView;
	private JLabel mSocketConnectStatus;
	private JTextField mModelEditView;
	private JTextField typeEditText;
	private JTextField idEditText;
	private JTextField valueEditText;
	private JTextField byteLocEditText;
	private JTextField bitLocEditText;

	private JTextField editPageName;
	private JTextField editPageSize;
	private JTextField editPageIntegrity;
	private JTextField editRxHeaderId;

	public MainView() {
		mProtocol = new Protocol();
		this.mSerialController = new SerialController(this, mProtocol);
		this.mSocketCommController = new SocketCommController(this, mProtocol);
		this.mSaveLoadController = new SaveLoadController(this, mProtocol);
		initialize();
	}

	private void initialize() {
		mMainFrame = new JFrame();
		mMainFrame.setTitle("");
		mMainFrame.setBounds(100, 100, 951, 719);
		mMainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mMainFrame.getContentPane().setLayout(new BorderLayout(0, 0));
		mMainFrame.setResizable(false);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		mMainFrame.getContentPane().add(tabbedPane, BorderLayout.CENTER);

		mPanel = new JPanel();
		tabbedPane.addTab("Tab1", null, mPanel, null);
		mPanel.setLayout(null);

		mProtocolInfoPanel = new JPanel();
		mProtocolInfoPanel.setBorder(new LineBorder(Color.DARK_GRAY, 1, true));
		mProtocolInfoPanel.setBounds(12, 107, 916, 545);
		mPanel.add(mProtocolInfoPanel);
		mProtocolInfoPanel.setLayout(null);

		initSerialConnect();
		initSocketConnect();
		initPageInfo();
		initPageInfoTable();
		initProtocolTable();

	}

	private void initSerialConnect() {
		JPanel serialConnectPanel = new JPanel();
		serialConnectPanel.setBorder(new LineBorder(new Color(64, 64, 64), 1, true));
		serialConnectPanel.setBounds(12, 10, 437, 87);
		mPanel.add(serialConnectPanel);
		serialConnectPanel.setLayout(null);

		JLabel lblBaudRate = new JLabel("Baud rate");
		lblBaudRate.setBounds(102, 10, 57, 15);
		serialConnectPanel.add(lblBaudRate);

		JLabel lblPort = new JLabel("Port");
		lblPort.setBounds(12, 10, 57, 15);
		serialConnectPanel.add(lblPort);

		JButton btnNewButton = new JButton("Connect");
		btnNewButton.setBounds(12, 55, 97, 23);
		serialConnectPanel.add(btnNewButton);

		JButton btnSystemPage = new JButton("Tx Start");
		btnSystemPage.setBounds(259, 10, 121, 23);
		serialConnectPanel.add(btnSystemPage);

		JButton btnCyclePage = new JButton("Tx Stop");
		btnCyclePage.setBounds(259, 41, 121, 23);
		serialConnectPanel.add(btnCyclePage);

		JButton btnDisconnect = new JButton("Disconnect");
		btnDisconnect.setBounds(114, 55, 97, 23);
		serialConnectPanel.add(btnDisconnect);
		btnDisconnect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mSerialController.stop();
				
				// load default data
				//mProtocol.setProtocolList(modelList);
				mProtocol.makeDefaultData(mModelEditView.getText().toString());
				clearPageTable();
				addPageItem(mProtocol.getProtocolList());
				clearProtocolTable();
				addProtocolItem(mProtocol.getDataList());
				
			}
		});
		
		mPortNumEditView = new JTextField();
		mPortNumEditView.setBounds(12, 28, 65, 21);
		serialConnectPanel.add(mPortNumEditView);
		mPortNumEditView.setColumns(10);
		mPortNumEditView.setText("COM23");

		mBaudRateEditView = new JTextField();
		mBaudRateEditView.setBounds(105, 28, 65, 21);
		serialConnectPanel.add(mBaudRateEditView);
		mBaudRateEditView.setColumns(10);
		mBaudRateEditView.setText("9600");
		
		btnCyclePage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mSerialController.doDataTxSendStop(SerialController.DATA_TX_STOP);
			}
		});
		btnSystemPage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mSerialController.doDataTxSendStop(SerialController.DATA_TX_START);
			}
		});
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String portNum = null;
				int baudRate = -1;
				String modelName = null;

				if (mPortNumEditView != null) {
					portNum = mPortNumEditView.getText().toString();
				}

				if (mBaudRateEditView != null) {
					baudRate = Integer.parseInt(mBaudRateEditView.getText().toString());
				}

				if (mModelEditView != null) {
					modelName = mModelEditView.getText().toString();
				}

				mSerialController.connect(portNum, baudRate, modelName);
			}
		});
	}

	private void initSocketConnect() {
		JPanel socketConnectPanel = new JPanel();
		socketConnectPanel.setBorder(new LineBorder(Color.DARK_GRAY, 1, true));
		socketConnectPanel.setBounds(461, 10, 467, 87);
		mPanel.add(socketConnectPanel);
		socketConnectPanel.setLayout(null);

		mSocketConnectStatus = new JLabel("");
		mSocketConnectStatus.setBounds(12, 54, 298, 23);
		socketConnectPanel.add(mSocketConnectStatus);
		mSocketConnectStatus.setBackground(Color.LIGHT_GRAY);

		JLabel lblComport = new JLabel("Port");
		lblComport.setBounds(140, 10, 57, 15);
		socketConnectPanel.add(lblComport);

		mServerIpEditView = new JTextField();
		mServerIpEditView.setBounds(12, 27, 97, 21);
		socketConnectPanel.add(mServerIpEditView);
		mServerIpEditView.setText("10.175.178.136");
		mServerIpEditView.setColumns(10);

		mServerPortEditView = new JTextField();
		mServerPortEditView.setBounds(139, 27, 47, 21);
		socketConnectPanel.add(mServerPortEditView);
		mServerPortEditView.setText("61000");
		mServerPortEditView.setColumns(10);

		JButton btnNewButton_2 = new JButton("Connect");
		btnNewButton_2.setBounds(213, 23, 97, 23);
		socketConnectPanel.add(btnNewButton_2);

		JLabel lblIp = new JLabel("Server IP");
		lblIp.setBounds(12, 10, 57, 15);
		socketConnectPanel.add(lblIp);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mSocketCommController.onClickLGMVConnectButton();
			}
		});
	}

	private void initPageInfo() {
		editPageName = new JTextField();
		editPageName.setBounds(12, 462, 85, 21);
		mProtocolInfoPanel.add(editPageName);
		editPageName.setColumns(10);

		editPageSize = new JTextField();
		editPageSize.setBounds(100, 462, 65, 21);
		mProtocolInfoPanel.add(editPageSize);
		editPageSize.setColumns(10);

		editPageIntegrity = new JTextField();
		editPageIntegrity.setBounds(168, 462, 65, 21);
		mProtocolInfoPanel.add(editPageIntegrity);
		editPageIntegrity.setColumns(10);

		editRxHeaderId = new JTextField();
		editRxHeaderId.setBounds(236, 462, 81, 21);
		mProtocolInfoPanel.add(editRxHeaderId);
		editRxHeaderId.setColumns(10);

		JLabel lblPageName = new JLabel("Page name");
		lblPageName.setBounds(12, 445, 65, 15);
		mProtocolInfoPanel.add(lblPageName);

		JLabel lblSize = new JLabel("Size");
		lblSize.setBounds(100, 445, 25, 15);
		mProtocolInfoPanel.add(lblSize);

		JLabel lblIntegrity = new JLabel("Integrity");
		lblIntegrity.setBounds(168, 445, 44, 15);
		mProtocolInfoPanel.add(lblIntegrity);

		JLabel lblRxHeaderId = new JLabel("Rx header ID");
		lblRxHeaderId.setBounds(236, 445, 73, 15);
		mProtocolInfoPanel.add(lblRxHeaderId);

		JButton btnSaveFile = new JButton("Save File");
		btnSaveFile.setBounds(150, 28, 85, 23);
		mProtocolInfoPanel.add(btnSaveFile);
		btnSaveFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mSaveLoadController.doSaveData();
			}
		});

		JButton btnLoadFile = new JButton("Load File");
		btnLoadFile.setBounds(240, 28, 85, 23);
		mProtocolInfoPanel.add(btnLoadFile);
		btnLoadFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mSaveLoadController.doLoadData();
			}
		});

		JLabel lblModel = new JLabel("Model");
		lblModel.setBounds(12, 11, 57, 15);
		mProtocolInfoPanel.add(lblModel);

		mModelEditView = new JTextField();
		mModelEditView.setBounds(12, 29, 126, 21);
		mProtocolInfoPanel.add(mModelEditView);
		mModelEditView.setText("Sync4");
		mModelEditView.setColumns(10);
	}


	private void initPageInfoTable() {
		// set the model to the table
		JScrollPane pageInfoTablePanel = new JScrollPane();
		pageInfoTablePanel.setBounds(12, 61, 313, 374);
		mProtocolInfoPanel.add(pageInfoTablePanel);

		Object[] pageTableRows = new Object[sPageTableColumns.length];
		mPageTableModel = new DefaultTableModel() {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		mPageTableModel.setColumnIdentifiers(sPageTableColumns);
		
		mPageInfoTable = new JTable();
		mPageInfoTable.setModel(mPageTableModel);
		pageInfoTablePanel.setViewportView(mPageInfoTable);

		mPageInfoTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int i = mPageInfoTable.getSelectedRow();
				editPageName.setText(mPageInfoTable.getValueAt(i, 0).toString());
				editPageSize.setText(mPageInfoTable.getValueAt(i, 1).toString());
				editPageIntegrity.setText(mPageInfoTable.getValueAt(i, 2).toString());
				editRxHeaderId.setText(mPageInfoTable.getValueAt(i, 3).toString());
			}
		});

		JButton btnDeletePage = new JButton("DELETE");
		btnDeletePage.setBounds(246, 489, 79, 23);
		mProtocolInfoPanel.add(btnDeletePage);
		btnDeletePage.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// i = the index of the selected row
				int i = mPageInfoTable.getSelectedRow();
				if (i >= 0) {
					String pageName = mPageInfoTable.getValueAt(i, 0).toString();
					if (mProtocol.removeProtocolModel(pageName) == true) {
						// remove a row from jtable
						mPageTableModel.removeRow(i);
					}
				} else {
					Utils.printLog(Utils.LogType.ERR, "Delete Error");
				}
			}
		});

		JButton btnAddPage = new JButton("ADD");
		btnAddPage.setBounds(178, 489, 57, 23);
		mProtocolInfoPanel.add(btnAddPage);
		btnAddPage.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				pageTableRows[0] = editPageName.getText();
				pageTableRows[1] = editPageSize.getText();
				pageTableRows[2] = editPageIntegrity.getText();
				pageTableRows[3] = editRxHeaderId.getText();

				String pageName = null;
				int pageSize = -1;
				String pageIntegrity = null;
				int pageRxHeaderId = -1;

				try {
					pageName = (String) pageTableRows[0];
					pageSize = Integer.parseInt((String) pageTableRows[1]);
					pageIntegrity = (String) pageTableRows[2];
					pageRxHeaderId = Integer.parseInt((String) pageTableRows[3]);
				} catch (Exception e2) {
					Utils.printLog(Utils.LogType.ERR, e2.getMessage());
				}

				if (pageName != null && pageSize > 0 && pageIntegrity != null && pageRxHeaderId > -1) {

					if (mProtocol.checkDuplicate(pageName) == true) {
						showMessage("Page name is duplicate");
					} else {
						ProtocolModel pm = new ProtocolModel(pageName, pageSize, pageIntegrity, pageRxHeaderId);
						mProtocol.addProtocolModel(pm);
						mPageTableModel.addRow(pageTableRows);
					}
				}
			}
		});
	}

	private void initProtocolTable() {

		Object[] protocolColumns = { TableHeader.PAGE_NAME.toString(), TableHeader.ID.toString(),
				TableHeader.INT_VALUE.toString(), TableHeader.HEX_VALUE.toString(), TableHeader.BYTE_LOC.toString(),
				TableHeader.BIT_LOC.toString(), TableHeader.RESULT };

		mProtocolTableModel = new DefaultTableModel() {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		mProtocolTableModel.setColumnIdentifiers(protocolColumns);

		// create an array of objects to set the row data
		Object[] protocolTableRows = new Object[TableHeader.values().length];

		mProtocolTable = new JTable();

		// set the model to the table
		mProtocolTable.setModel(mProtocolTableModel);

		JScrollPane protocolTablePanel = new JScrollPane();
		protocolTablePanel.setBounds(337, 10, 567, 425);
		mProtocolInfoPanel.add(protocolTablePanel);

		protocolTablePanel.setViewportView(mProtocolTable);

		JLabel lblType = new JLabel(TableHeader.PAGE_NAME.toString());
		lblType.setBounds(337, 445, 65, 15);
		mProtocolInfoPanel.add(lblType);

		JLabel lblId = new JLabel(TableHeader.ID.toString());
		lblId.setBounds(470, 445, 10, 15);
		mProtocolInfoPanel.add(lblId);

		JLabel lblValue = new JLabel(TableHeader.INT_VALUE.toString());
		lblValue.setBounds(590, 445, 64, 15);
		mProtocolInfoPanel.add(lblValue);

		JLabel lblByteLocation = new JLabel(TableHeader.BYTE_LOC.toString());
		lblByteLocation.setBounds(695, 445, 25, 15);
		mProtocolInfoPanel.add(lblByteLocation);

		JLabel lblBitLocation = new JLabel(TableHeader.BIT_LOC.toString());
		lblBitLocation.setBounds(803, 445, 14, 15);
		mProtocolInfoPanel.add(lblBitLocation);

		typeEditText = new JTextField();
		typeEditText.setBounds(337, 462, 126, 21);
		mProtocolInfoPanel.add(typeEditText);
		typeEditText.setColumns(10);

		idEditText = new JTextField();
		idEditText.setBounds(470, 462, 116, 21);
		mProtocolInfoPanel.add(idEditText);
		idEditText.setColumns(10);

		valueEditText = new JTextField();
		valueEditText.setBounds(590, 462, 101, 21);
		mProtocolInfoPanel.add(valueEditText);
		valueEditText.setColumns(10);

		byteLocEditText = new JTextField();
		byteLocEditText.setBounds(697, 462, 101, 21);
		mProtocolInfoPanel.add(byteLocEditText);
		byteLocEditText.setColumns(10);

		bitLocEditText = new JTextField();
		bitLocEditText.setBounds(803, 462, 101, 21);
		mProtocolInfoPanel.add(bitLocEditText);
		bitLocEditText.setColumns(10);

		mProtocolTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int i = mProtocolTable.getSelectedRow();

				typeEditText.setText(mProtocolTableModel.getValueAt(i, TableHeader.PAGE_NAME.ordinal()).toString());
				idEditText.setText(mProtocolTableModel.getValueAt(i, TableHeader.ID.ordinal()).toString());
				valueEditText.setText(mProtocolTableModel.getValueAt(i, TableHeader.INT_VALUE.ordinal()).toString());
				byteLocEditText.setText(mProtocolTableModel.getValueAt(i, TableHeader.BYTE_LOC.ordinal()).toString());
				bitLocEditText.setText(mProtocolTableModel.getValueAt(i, TableHeader.BIT_LOC.ordinal()).toString());
			}
		});

		JButton btnProtocolAdd = new JButton("ADD");
		btnProtocolAdd.setBounds(663, 489, 57, 23);
		mProtocolInfoPanel.add(btnProtocolAdd);
		btnProtocolAdd.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				protocolTableRows[TableHeader.PAGE_NAME.ordinal()] = typeEditText.getText();
				protocolTableRows[TableHeader.ID.ordinal()] = idEditText.getText();
				protocolTableRows[TableHeader.INT_VALUE.ordinal()] = valueEditText.getText();
				protocolTableRows[TableHeader.BYTE_LOC.ordinal()] = byteLocEditText.getText();
				protocolTableRows[TableHeader.BIT_LOC.ordinal()] = bitLocEditText.getText();
				protocolTableRows[TableHeader.RESULT.ordinal()] = "";

				if (validateInputValue(typeEditText.getText(), idEditText.getText(), valueEditText.getText(),
						byteLocEditText.getText(), bitLocEditText.getText()) != InputCheck.SUCCESS) {
					return;
				}

				String pageName = (String) protocolTableRows[TableHeader.PAGE_NAME.ordinal()];
				if (mProtocol.checkDuplicate(pageName) == false) {
					showMessage("Page name does not exist.");
					return;
				}

				String id = (String) protocolTableRows[TableHeader.ID.ordinal()];
				Integer value = convertIntValue((String) protocolTableRows[TableHeader.INT_VALUE.ordinal()]);
				protocolTableRows[TableHeader.HEX_VALUE.ordinal()] = Utils.getHexValueStr(value);
				List<Integer> posByte = convertIntArray((String) protocolTableRows[TableHeader.BYTE_LOC.ordinal()]);
				List<Integer> posBit = convertIntArray((String) protocolTableRows[TableHeader.BIT_LOC.ordinal()]);

				DataVO data = new DataVO(pageName, id, posByte, posBit, value);
				if (mProtocol.addDataVO(pageName, data) == true) {
					mProtocolTableModel.addRow(protocolTableRows);
				} else {
					showMessage("fail to add DataVO");
				}

			}
		});

		JButton btnUpdateProtocol = new JButton("UPDATE");
		btnUpdateProtocol.setBounds(732, 489, 81, 23);
		mProtocolInfoPanel.add(btnUpdateProtocol);
		btnUpdateProtocol.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				// i = the index of the selected row
				int i = mProtocolTable.getSelectedRow();

				if (i >= 0) {
					if (validateInputValue(typeEditText.getText(), idEditText.getText(), valueEditText.getText(),
							byteLocEditText.getText(), bitLocEditText.getText()) != InputCheck.SUCCESS) {
						return;
					}

					String pageName = typeEditText.getText();
					if (mProtocol.checkDuplicate(pageName) == false) {
						showMessage("Page name does not exist.");
						return;
					}

					String id = idEditText.getText();
					Integer value = convertIntValue(valueEditText.getText());
					List<Integer> posByte = convertIntArray(byteLocEditText.getText());
					List<Integer> posBit = convertIntArray(bitLocEditText.getText());

					if (mProtocol.updateDataVO(pageName, id, value, posByte, posBit)) {
						mProtocolTableModel.setValueAt(typeEditText.getText(), i, TableHeader.PAGE_NAME.ordinal());
						mProtocolTableModel.setValueAt(idEditText.getText(), i, TableHeader.ID.ordinal());
						mProtocolTableModel.setValueAt(valueEditText.getText(), i, TableHeader.INT_VALUE.ordinal());
						int val = convertIntValue(valueEditText.getText());
						mProtocolTableModel.setValueAt(Utils.getHexValueStr(val), i, TableHeader.HEX_VALUE.ordinal());
						mProtocolTableModel.setValueAt(byteLocEditText.getText(), i, TableHeader.BYTE_LOC.ordinal());
						mProtocolTableModel.setValueAt(bitLocEditText.getText(), i, TableHeader.BIT_LOC.ordinal());
					} else {
						showMessage("fail to update DataVO");
					}

				} else {
					Utils.printLog(Utils.LogType.ERR, "Update Error");
				}
			}
		});

		JButton btnDeleteProtocol = new JButton("DELETE");
		btnDeleteProtocol.setBounds(825, 489, 79, 23);
		mProtocolInfoPanel.add(btnDeleteProtocol);
		btnDeleteProtocol.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// i = the index of the selected row
				int i = mProtocolTable.getSelectedRow();
				if (i >= 0) {
					String pageName = mProtocolTable.getValueAt(i, TableHeader.PAGE_NAME.ordinal()).toString();
					String idStr = mProtocolTable.getValueAt(i, TableHeader.ID.ordinal()).toString();
					if (mProtocol.removeDataVO(pageName, idStr) == true) {
						mProtocolTableModel.removeRow(i);
					}
				} else {
					Utils.printLog(Utils.LogType.ERR, "Delete Error");
				}
			}
		});
	}

	private InputCheck validateInputValue(String typeText, String idText, String valueText, String byteLocText,
			String bitLocText) {
		if (typeText == null || typeText.length() == 0) {
			showMessage("[ERROR] Input value : TYPE");
			return InputCheck.ERROR_TYPE;
		}
		if (idText == null || idText.length() == 0) {
			showMessage("[ERROR] Input value : ID");
			return InputCheck.ERROR_ID;
		}
		if (valueText == null || valueText.length() == 0 || convertIntValue(valueText) == null) {
			showMessage("[ERROR] Input value : VALUE");
			return InputCheck.ERROR_VALUE;
		}
		if (byteLocText == null || byteLocText.length() == 0 || convertIntArray(byteLocText) == null) {
			showMessage("[ERROR] Input value : BYTE LOCATION");
			return InputCheck.ERROR_BYTE_LOC;
		}

		return InputCheck.SUCCESS;
	}

	private List<Integer> convertIntArray(String str) {
		if (str == null) {
			return null;
		}

		StringBuffer sb = new StringBuffer();
		sb.append(str.trim());

		int start = sb.indexOf("[");
		if (start < 0) {
			return null;
		}
		sb = sb.delete(0, start);

		int end = sb.indexOf("]");
		if (end < 0) {
			return null;
		}

		String parsingText = sb.substring(1, end);
		sb = sb.delete(0, end + 1);

		String[] arr = parsingText.split(",");

		if (arr == null || arr.length == 0) {
			return null;
		}

		List<Integer> retArr = new ArrayList<>();
		try {
			for (int i = 0; i < arr.length; i++) {
				retArr.add(Integer.parseInt(arr[i].trim()));
			}
		} catch (NumberFormatException e) {
			Utils.printLog(Utils.LogType.ERR, e.getMessage());
			retArr = null;
		}

		if (retArr != null && retArr.size() > 0) {
			return retArr;
		} else {
			return null;
		}
	}

	private Integer convertIntValue(String valueStr) {
		if (valueStr == null) {
			return null;
		}

		Integer ret = null;
		try {
			ret = Integer.parseInt(valueStr);
		} catch (NumberFormatException e) {
			Utils.printLog(Utils.LogType.ERR, e.getMessage());
		}
		return ret;
	}

	public boolean clearProtocolTable() {
		if (mProtocolTableModel == null) {
			return false;
		}

		mProtocolTableModel.getDataVector().removeAllElements();
		mProtocolTableModel.fireTableDataChanged();
		return true;
	}

	public boolean clearPageTable() {
		if (mPageTableModel == null) {
			return false;
		}

		mPageTableModel.getDataVector().removeAllElements();
		mPageTableModel.fireTableDataChanged();
		return true;
	}

	public static int getIndex(String[] array, String findId) {
		if (array == null || array.length == 0 || findId == null) {
			return -1;
		}

		for (int i = 0; i < array.length; i++) {
			if (findId.equalsIgnoreCase(array[i])) {
				return i;
			}
		}
		return -1;
	}

	public void showWindow() {
		this.mMainFrame.setVisible(true);
	}

	public void setProtocolItem(List<DataVO> list) {
		if (list == null || list.isEmpty() == true) {
			return;
		}
		for (int i = 0; i < list.size(); i++) {
			DataVO data = list.get(i);
			mProtocolTableModel.setValueAt(data.getPageType(), i, TableHeader.PAGE_NAME.ordinal());
			mProtocolTableModel.setValueAt(data.getId(), i, TableHeader.ID.ordinal());
			mProtocolTableModel.setValueAt(data.getIntValue(), i, TableHeader.INT_VALUE.ordinal());
			mProtocolTableModel.setValueAt(data.getHexValue(), i, TableHeader.HEX_VALUE.ordinal());
			mProtocolTableModel.setValueAt(data.getPosByte(), i, TableHeader.BYTE_LOC.ordinal());
			mProtocolTableModel.setValueAt(data.getPosBit(), i, TableHeader.BIT_LOC.ordinal());
			mProtocolTableModel.setValueAt(data.getCheckValue(), i, TableHeader.RESULT.ordinal());

		}
	}

	public void addProtocolItem(List<DataVO> list) {
		if (list == null || list.isEmpty() == true) {
			return;
		}

		for (int i = 0; i < list.size(); i++) {
			DataVO data = list.get(i);
			Object[] row = new Object[TableHeader.values().length];

			row[TableHeader.PAGE_NAME.ordinal()] = data.getPageType();
			row[TableHeader.ID.ordinal()] = data.getId();
			row[TableHeader.INT_VALUE.ordinal()] = Integer.toString(data.getIntValue());
			row[TableHeader.HEX_VALUE.ordinal()] = data.getHexValue();
			row[TableHeader.BYTE_LOC.ordinal()] = Utils.convertIntArrToString(data.getPosByte());
			row[TableHeader.BIT_LOC.ordinal()] = Utils.convertIntArrToString(data.getPosBit());
			row[TableHeader.RESULT.ordinal()] = data.getCheckValue();
			mProtocolTableModel.addRow(row);
		}
	}

	public void addPageItem(List<ProtocolModel> list) {
		if (list == null || list.isEmpty() == true) {
			return;
		}

		for (int i = 0; i < list.size(); i++) {
			ProtocolModel pm = list.get(i);
			Object[] row = new Object[sPageTableColumns.length];
			row[0] = pm.name;
			row[1] = pm.size;
			row[2] = pm.integrityType;
			row[3] = pm.rxHeaderId;
			mPageTableModel.addRow(row);
		}
	}

	public String getLGMVIP() {
		return mServerIpEditView.getText();
	}

	public void setLGMVIP(String ip) {
		// lgmvIPTextField.setText(ip);
	}

	public String getLGMVPort() {
		return mServerPortEditView.getText();
	}

	public void setLGMVPort(String port) {
		// lgmvPortTextField.setText(port);
	}

	public void setLGMVConnectStatus(int status) {
		switch (status) {
		case SOCKET_STATUS_CONNECT:
			mSocketConnectStatus.setText("Connection status: 연결됨");
			break;
		case SOCKET_STATUS_STOP:
		case SOCKET_STATUS_CONNECT_ERROR:
			mSocketConnectStatus.setText("Connection status: 연결 끊김");
			break;
		}
	}

	public void showMessage(String message) {
		JOptionPane.showMessageDialog(mMainFrame, message);
	}
}
