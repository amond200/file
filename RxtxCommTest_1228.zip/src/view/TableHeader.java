package view;

public enum TableHeader {

	PAGE_NAME("Page name"),
	ID("Id"),
	INT_VALUE("Value(Dec)"),
	HEX_VALUE("Value(Hex)"),
	BYTE_LOC("Byte"),
	BIT_LOC("Bit"),
	RESULT("Result")
	;

	private final String text;

	/**
	 * @param text
	 */
	TableHeader(final String text) {
		this.text = text;
	}

	/* (non-Javadoc)
	 * @see java.lang.Enum#toString()
	 */
	@Override
	public String toString() {
		return text;
	}

}
