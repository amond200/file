package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import common.Utils;
import data.DataVO;
import data.Protocol;

public class ProtocolTest {

	public static String parsingDummy = "[air_temp:0:0,comp1_oil_level:0:0,comp2_oil_level:0:0,comp_limit_ct:0:0,comp_limit_temp:0:0,comp_limit_vt:0:0,comp_overload:0:0,comp_ratio:0:-,condensing_temp:0:0,eep_ver:0:4.5.6 / ,evaporating_temp:0:0,fan1_target:0:be,fan1_trace:0:a,fan1_up_current:0:0,fan2_trace:0:0,fan2_up_current:0:0,fan_dc_link_voltage:0:0,fan_error:0:0,fan_heatsink_temp:0:0,heat_exchanger_down_temp:0:0,heat_exchanger_temp:0:0,heat_exchanger_up_temp:0:0,hex_valve:0:0,highpress_target:0:32,highpress_trace:0:0,idu_temp_weighted_average:0:0,inv1_dc_link_voltage:0:0,inv1_discharge_temp:0:0,inv1_frequency_input_voltage:0:0,inv1_input_current:0:0,inv1_input_voltage:0:0,inv1_ipm_temp:0:0,inv1_target:0:c8,inv1_trace:0:64,inv1_up_current:0:0,inv2_dc_link_voltage:0:0,inv2_discharge_temp:0:0,inv2_frequency_input_voltage:0:0,inv2_input_current:0:0,inv2_input_voltage:0:0,inv2_ipm_temp:0:0,inv2_target:0:0,inv2_trace:0:0,inv2_up_current:0:0,inv_error:0:0,lowpress_target:0:3c,lowpress_trace:0:0,main_eev:0:0,micom_ver:0:2.3 / ,nominal_capacity:0:1,oil_eq_eev:0:0,oper_mode:0:1,port_4way:0:0,port_accum_valve:0:1,port_hex_high_valve:0:0,port_hex_low_valve:0:0,port_inv2_perheat:0:0,port_inv_preheat:0:1,port_receiver_in:0:0,port_receiver_out:0:1,sc_eev:0:0,sc_pipe_in_temp:0:0,sc_pipe_liquid_pipe_temp:0:0,sc_pipe_out_temp:0:0,sc_trace:0:-,scsh_target:0:0,scsh_trace:0:-,sh_target:0:0,sh_trace:0:-,snow_deep:0:0,sub_eev:0:0,suction_temp:0:0,suction_valve:0:0,vi_eev1:0:0,vi_eev2:0:0]";

	@Test
	public void test_parsing() {
		
		
		Protocol protocol = new Protocol();
		protocol.makeDefaultData("sync4");
		
//		protocol.makePacket(2);
		
		String parStr = protocol.parsing(parsingDummy);
//		System.out.println("parStr : " + parStr);
		
		Map<String, String> retMap = protocol.getVerificationMap(parStr);
		System.out.println(retMap);
		boolean ret = false;
		for(String key :retMap.keySet()){
			//testMap.get(key)
			DataVO data = protocol.getDataVO(key);
			if (data != null) {
				System.out.println(data.getHexValue() + "/" + retMap.get(key));
				data.setCheckValue((data.getHexValue().equalsIgnoreCase(retMap.get(key)) ? DataVO.CHECK_SUCCESS:DataVO.CHECK_FAIL));
				ret = true;
				break;
			} 
		}
		
		assertEquals(true, ret);
		
//		protocol.updateData();

	}

}
