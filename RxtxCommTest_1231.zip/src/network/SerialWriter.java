package network;

import java.io.OutputStream;
import java.util.List;

import common.Utils;
import controller.SerialController;
import data.ProtocolModel;


public class SerialWriter implements Runnable {
	private OutputStream mOutStream;
	private SerialController mController;

	public SerialWriter(OutputStream out, SerialController controller) {
		this.mOutStream = out;
		this.mController = controller;
	}

	public void run() {

		Utils.printLog(Utils.LogType.INFO, "txRun: " + mController.getSendFlag() + " / txType: " + mController.getTxHeaderType());

		while(mController.getSendFlag()){
			try {
				
//				int sendPacketCnt = mController.getProtocol().makeSendProtocolList(mController.getTxHeaderType());
//				Utils.printLog(Utils.LogType.INFO, "header type: " + mController.getTxHeaderType() + " / sendPacketCnt: " + sendPacketCnt);
//				
//				for (int i = 0 ; i < sendPacketCnt ; i++) {
//					byte txData[] = mController.getProtocol().makePacket(i);
//					Utils.printLog(Utils.LogType.INFO, "[DATA_TX] txData.length: " + txData.length);
//					if (txData != null && txData.length > 0) {
//						this.mOutStream.write(txData, 0, txData.length);  
//						mController.updateTxPacketCount();
//						Utils.printLog(Utils.LogType.ERR, "[DATA_TX] txType: " + mController.getTxHeaderType() + " / size: " + txData.length);
//						Utils.printLog(Utils.LogType.ERR,"[DATA_TX] data: " + Utils.byteArrayToHexString(txData));
//						Thread.sleep(500);
//					}
//				}
				
				System.out.println(mController.getProtocol().getProtocolList());
				List<ProtocolModel> sendList = mController.getProtocol().getSendProtocolList(mController.getTxHeaderType());
				System.out.println("headerType: " + mController.getTxHeaderType() + " / sendList size: " + sendList.size());
				for (ProtocolModel item : sendList) {
					byte txData[] = item.makePacket();
					if (txData != null && txData.length > 0) {
						this.mOutStream.write(txData, 0, txData.length);  
						mController.updateTxPacketCount();
						Utils.printLog(Utils.LogType.ERR, "[DATA_TX] txType: " + mController.getTxHeaderType() + " / size: " + txData.length);
						Utils.printLog(Utils.LogType.ERR,"[DATA_TX] data: " + Utils.byteArrayToHexString(txData));
						Thread.sleep(100);
					}
				}
				
				
				
//				switch (mController.getTxHeaderType()) {
//				case 2:
//					txData = mController.getProtocol().makeCycleInfoPacket(0);
//					this.mOutStream.write(txData, 0, txData.length);
//
//					Thread.sleep(500);
//					txData = mController.getProtocol().makeCycleInfoPacket(1);
//					this.mOutStream.write(txData, 0, txData.length);
//
//					Thread.sleep(500);
//					txData = mController.getProtocol().makeCycleInfoPacket(2);
//					this.mOutStream.write(txData, 0, txData.length);
//
//					Thread.sleep(500);
//					txData = mController.getProtocol().makeCycleInfoPacket(3);
//					this.mOutStream.write(txData, 0, txData.length);
//
//					Thread.sleep(500);
//					txData = mController.getProtocol().makeCommCountPacket(10);
//					this.mOutStream.write(txData, 0, txData.length);
//
//					Thread.sleep(500);
//					txData = mController.getProtocol().makeDataPacket();
//					this.mOutStream.write(txData, 0, txData.length);
//					
//					mController.updateTxPacketCount();
//					
//					break;
//				default:
//					txData = mController.getProtocol().makeSystemInfoPacket();
//					this.mOutStream.write(txData, 0, txData.length);  
//					break;
//				}
//				Thread.sleep(500);

			} catch (Exception e) {
				e.printStackTrace();
				mController.setSendFlag(false);
			}
		}

	}



}
