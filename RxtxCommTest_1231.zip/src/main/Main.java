package main;

import java.awt.EventQueue;
import javax.swing.UIManager;

import view.MainView;

public class Main {

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
					MainView window = new MainView();
					window.showWindow();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

	}

}
