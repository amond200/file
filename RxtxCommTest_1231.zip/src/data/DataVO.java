package data;

import java.util.ArrayList;
import java.util.List;

import common.Utils;

public class DataVO { //implements Comparable<DataVO>{
	public static final String CHECK_NULL = "";
	public static final String CHECK_FAIL = "FAIL";
	public static final String CHECK_SUCCESS = "PASS";

	private String mPageName;
	private int mPageCount;	// Unit Count
	private String mId;
	private List<Integer> mPosByte;
	private List<Integer> mPosBit;
	private int mIntValue;
	private String mResult;

	public DataVO(String pageName, int pageCount, String id, List<Integer> bytePos, List<Integer> bitPos, int intValue) {
		super();
		this.mId = id;
		this.mPageName = pageName;
		this.mPageCount = pageCount;
		this.mPosByte = bytePos;
		this.mPosBit = bitPos;
		this.mIntValue = intValue;
		this.mResult = CHECK_NULL;
	}

	public DataVO(String pageName, int pageCount, String id, int[] bytePos, int[] bitPos, int intValue) {
		super();
		this.mId = id;
		this.mPageName = pageName;
		this.mPageCount = pageCount;
		this.mPosByte = new ArrayList<>();
		if (bytePos != null && bytePos.length > 0) {
			for (int i = 0; i < bytePos.length ; i++) {
				this.mPosByte.add(bytePos[i]);
			}
		} else {
			this.mPosByte = null;
		}
		this.mPosBit = new ArrayList<>();
		if (bitPos != null && bitPos.length > 0) {
			for (int i = 0; i < bitPos.length ; i++) {
				this.mPosBit.add(bitPos[i]);
			}
		} else {
			this.mPosBit = null;
		}
		this.mIntValue = intValue;
		this.mResult = CHECK_NULL;
	}

	public String getPageType() {
		return mPageName;
	}
	
	public void setPageType(String pageName) {
		this.mPageName = pageName;
	}
	
	public int getPageCount() {
		return mPageCount;
	}
	
	public void setPageCount(int pageCount) {
		this.mPageCount = pageCount;
	}
	
	public void setId(String id) {
		this.mId = id;
	}

	public String getId() {
		return mId;
	}
	
	public List<Integer> getPosByte() {
		return mPosByte;
	}

	public void setPosByte(List<Integer> posByte) {
		this.mPosByte = posByte;
	}

	public List<Integer> getPosBit() {
		return mPosBit;
	}

	public void setPosBit(List<Integer> posBit) {
		this.mPosBit = posBit;
	}

	public int getIntValue() {
		return mIntValue;
	}
	
	public void setIntValue(int intValue) {
		this.mIntValue = intValue;
	}

	public String getCheckValue() {
		return mResult;
	}

	public void setCheckValue(String result) {
		this.mResult = result;
	}

	public String getHexValue() {
		byte[] tmp = new byte[1];
		tmp[0] = (byte)mIntValue;
		return String.format("%X",Utils.byteToUnsignedInt(tmp[0]));
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("PageName: " + mPageName);
		sb.append(" / ");
		sb.append("PageCount: " + mPageCount);
		sb.append(" / ");
		sb.append("Id: " + mId);
		sb.append(" / ");
		sb.append("PosByte: " + mPosByte);
		sb.append(" / ");
		sb.append("PosBit: " + mPosBit);
		sb.append(" / ");
		sb.append("Value: " + mIntValue);
		sb.append(" / ");
		sb.append("Result: " + mResult);
		return sb.toString();
	}

}