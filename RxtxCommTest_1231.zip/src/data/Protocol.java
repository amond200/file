package data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import common.IProtocolParserId;
import common.Utils;
import sampleData.Sync4;

public class Protocol implements IProtocolParserId {

	public static final int EMPTY_DATA = 0;

	private List<ProtocolModel> mProtocolList;

	private List<ProtocolModel> mSendList;

	//	private String mParsingText = null;
	//	private StringBuffer mStrBuffer = new StringBuffer();

	public Protocol() {
		mProtocolList = new ArrayList<>();
	}

	public void setProtocolList(List<ProtocolModel> list) {
		this.mProtocolList = list;
	}

	public void addProtocolModel(ProtocolModel pm) {
		mProtocolList.add(pm);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		if (mProtocolList != null) {
			sb.append("===========<mProtocolList>===========\n");
			sb.append("mProtocolList.size: " + mProtocolList.size());
			for (ProtocolModel pm : mProtocolList) {
				sb.append(pm.toString());
			}
		}

		if (mSendList != null) {
			sb.append("\n");
			sb.append("===========<mSendList>===========\n");
			sb.append("mSendList.size: " + mSendList.size());
			for (ProtocolModel send : mSendList) {
				sb.append(send.toString());
			}
		}
		return sb.toString();
	}

	public boolean hasDuplicatePage(String pageName, int pageCount) {
		return getProtocolModel(pageName, pageCount) == null ? false : true;
	}
	
	public boolean hasDuplicateDataId(String pageName, int pageCount, String id) {
		
		ProtocolModel pm = getProtocolModel(pageName, pageCount);
		if (pm == null) {
			return false;
		}
		
		for (DataVO dv : pm.mData) {
			if (dv.getId().equalsIgnoreCase(id)) {
				return true;
			}
		}
		
		return false;
	}

	public boolean removeProtocolModel(String pageName, int pageCount) {
		ProtocolModel pm = getProtocolModel(pageName, pageCount);
		if (pm == null) {
			return false;
		}

		mProtocolList.remove(pm);
		return true;
	}

	public ProtocolModel getProtocolModel(String pageName, int pageCount) {
		for (ProtocolModel pm : mProtocolList) {
			if (pm.pageName.equalsIgnoreCase(pageName) && pm.pageCount == pageCount) {
				return pm;
			}
		}
		return null;
	}

	public List<ProtocolModel> getProtocolModelList(int rxHeaderType) {
		List<ProtocolModel> ret = new ArrayList<>(); 
		for (ProtocolModel pm : mProtocolList) {
			if (pm.rxHeaderId == rxHeaderType) {
				ret.add(pm);
			}
		}
		return ret;
	}

	public boolean addDataVO(String pageName, int pageCount, DataVO item) {
		ProtocolModel pm = getProtocolModel(pageName, pageCount);
		if (pm == null) {
			return false;
		}
		pm.mData.add(item);
		return true;
	}

	public boolean updateDataVO(String pageName, int pageCount, String id, Integer value, List<Integer> posByte, List<Integer> posBit) {
		ProtocolModel pm = getProtocolModel(pageName, pageCount);
		if (pm == null) {
			return false;
		}

		for (DataVO dv : pm.mData) {
			if (dv.getId().equalsIgnoreCase(id)) {
				dv.setIntValue(value);
				dv.setPosByte(posByte);
				dv.setPosBit(posBit);
				return true;
			}
		}
		return false;
	}

	public boolean removeDataVO(String pageName, int pageCount, String id) {
		ProtocolModel pm = getProtocolModel(pageName, pageCount);
		if (pm == null) {
			return false;
		}
		for (DataVO dv : pm.mData) {
			if (dv.getId().equalsIgnoreCase(id)) {
				pm.mData.remove(dv);
				return true;
			}
		}
		return false;
	}

	public List<ProtocolModel> getProtocolList() {
		return this.mProtocolList;
	}

	public List<DataVO> getDataList() {
		List<DataVO> dataList = new ArrayList<>();
		for (ProtocolModel pm : mProtocolList) {
			dataList.addAll(pm.mData);
		}
		return dataList;
	}

	public String parsing(String text){
		String parsingText = null;
		StringBuffer sb = new StringBuffer();
		if(text != null){
			sb.append(text.trim());
		}
		int start = sb.indexOf("[");
		if(start < 0){
			return null;
		}
		sb = sb.delete(0, start);
		int end = sb.indexOf("]");
		if(end < 0){
			return null;
		}
		parsingText = sb.substring(1, end);
		sb = sb.delete(0, end+1);
		return parsingText;
	}

	// comp1_oil_level:0:0 -> <comp1_oil_level#0, 0>
	public Map<String, String> getVerificationMap(String parsingText) {
		//OLD LGMV : ODU1.SEC1.TXT_LOW_PRESSURE_TRACE:1222:UNIT_KPA,
		//NEW LGMV : comp1_oil_level:0:0,
		Map<String, String> returnMap = new HashMap<>();
		if (parsingText == null) {
			return returnMap;
		}
		String textArray[] = parsingText.split(",");
		//		mParsingText = null;
		for(int i = 0; i < textArray.length; i++){
			String dataArray[] = textArray[i].split(":");
			returnMap.put(dataArray[0].trim(), dataArray[2].trim());
		}
		return returnMap;
	}

	public boolean updateData(String parsingText) {
		if (parsingText == null) {
			return false;
		}

		boolean ret = false;
		Map<String, String> returnMap = getVerificationMap(parsingText);
		if (returnMap.size() == 0) {
			return ret;
		}

		for(String key :returnMap.keySet()){
			DataVO data = getDataVO(key);

			if (data != null) {
				data.setCheckValue((data.getHexValue().equalsIgnoreCase(returnMap.get(key)) ? DataVO.CHECK_SUCCESS:DataVO.CHECK_FAIL));
				ret = true;
			} 
		}

		return ret;
	}

	public String updateValueAndGetHexValue(String id, int value) {
		DataVO data = getDataVO(id);
		if (data != null) {
			data.setIntValue(value);
			return data.getHexValue();
		}

		return null;
	}

	public void updateId(String id, String newId) {
		DataVO data = getDataVO(id);
		if (data != null) {
			data.setId(newId);
		}
	}


	public DataVO getDataVO(String id) {
		for (DataVO item : getDataList()) {
			if (item.getId().equals(id)) {
				return item;
			}
		}
		return null;
	}

	public void makeDefaultData(String modelName) {
		if ("sync4".equalsIgnoreCase(modelName)) {

			int oduCnt = 4;
			int iduCnt = 10;
			int hruCnt = 9;

			mProtocolList.clear();

			String pageName = TYPE_SYSTEM;
			mProtocolList.add(new ProtocolModel(pageName, 0, 31, "crc8", 0, Sync4.makeSystemData(pageName, 0, iduCnt, hruCnt)));

			for (int i = 0 ; i < oduCnt ; i++) {
				pageName = TYPE_CYCLE; // + "_" + i;
				mProtocolList.add(new ProtocolModel(pageName, i, 67, "crc16", 2, Sync4.makeCycleData(pageName, i)));
			}

			pageName = TYPE_COMM_COUNT;
			mProtocolList.add(new ProtocolModel(pageName, 0, iduCnt+4, "crc8", 2, Sync4.makeCommuncationCount(pageName, 0)));

			for (int i = 0 ; i < iduCnt ; i++) {
				pageName = TYPE_IDU; // + "_" + i;
				mProtocolList.add(new ProtocolModel(pageName, i, 17, "crc8", 2, Sync4.makeIduData(pageName, i)));
			}

			pageName = TYPE_DEV_DATA;
			mProtocolList.add(new ProtocolModel(pageName, 0, 14, "crc8", 2, Sync4.makeDevData(pageName, 0)));

		}
	}

	public int makeSendProtocolList(int headerType) {

		// init list
		if (mSendList == null) {
			mSendList = new ArrayList<>();
		} else {
			mSendList.clear();
		}

		mSendList = getProtocolModelList(headerType);
		if (mSendList.isEmpty()) {
			ProtocolModel systemModel = getProtocolModel(TYPE_SYSTEM, 0);	// TODO
			if (systemModel == null) {
				return -1;
			} else {
				mSendList.add(systemModel);
			}
		}
		return mSendList.size();
	}
	
	public List<ProtocolModel> getSendProtocolList(int headerType) {

		List<ProtocolModel> sendList = getProtocolModelList(headerType);

		if (sendList.isEmpty()) {
			ProtocolModel systemModel = getProtocolModel(TYPE_SYSTEM, 0);	// TODO
			if (systemModel == null) {
				return sendList;
			} else {
				sendList.add(systemModel);
			}
		}
		return sendList;
	}

	public byte[] makePacket(int sendPacketIndex){
		if (mSendList == null) {
			return null;
		}
		ProtocolModel model = mSendList.get(sendPacketIndex);
		if (model == null) {
			return null;
		}
		byte[] buffer = new byte[model.pageSize];
		buffer[0] = 0x02;
		buffer[1] = (byte)model.pageSize;
		for (int i = 2; i < model.getDataLastIndex(); i++) {
			buffer[i] = (byte)getData(model.pageName, i);
		}
		model.setIntegrityTypeValue(buffer);
		return buffer;
	}

	//	public byte[] makePacket(int headerType){
	//		ProtocolModel model = getProtocolModelList(headerType);
	//		if (model == null) {
	//			model = getProtocolModel(TYPE_SYSTEM);
	//		}
	//		if (model == null) {
	//			return null;
	//		}
	//		byte[] buffer = new byte[model.size];
	//		buffer[0] = 0x02;
	//		buffer[1] = (byte)model.size;
	//		for (int i = 2; i < model.getDataLastIndex(); i++) {
	//			buffer[i] = (byte)getData(model.name, i);
	//		}
	//		model.setIntegrityTypeValue(buffer);
	//		return buffer;
	//	}

	//	public byte[] makeSystemInfoPacket(){
	//		ProtocolModel model = null;
	//		for (ProtocolModel pm : mProtocolList) {
	//			if (TYPE_SYSTEM.equals(pm.name)) {
	//				model = pm;
	//				break;
	//			}
	//		}
	//		byte[] buffer = new byte[model.size];
	//		buffer[0] = 0x02;
	//		buffer[1] = (byte)model.size;
	//		for (int i = 2; i < model.getDataLastIndex(); i++) {
	//			buffer[i] = (byte)getData(TYPE_SYSTEM, i);
	//		}		
	//		model.setIntegrityTypeValue(buffer);
	//		Utils.printLog(Utils.LogType.DEBUG, "makeSystemInfoPacket: " + Utils.byteArrayToHexString(buffer));
	//		return buffer;
	//	}

	public byte[] makeCycleInfoPacket(int oduNum){
		ProtocolModel model = null;
		for (ProtocolModel pm : mProtocolList) {
			if (TYPE_CYCLE.equals(pm.pageName)) {
				model = pm;
				break;
			}
		}
		byte[] buffer = new byte[model.pageSize];
		buffer[0] = 0x02;
		buffer[1] = (byte)model.pageSize;
		buffer[2] = (byte)(101+oduNum);
		for (int i = 3; i < model.getDataLastIndex(); i++) {
			buffer[i] = (byte)getData(TYPE_CYCLE, i);
		}
		model.setIntegrityTypeValue(buffer);
		Utils.printLog(Utils.LogType.DEBUG, "makeCycleInfoPacket: " + Utils.byteArrayToHexString(buffer));
		return buffer;
	}

	public byte[] makeCommCountPacket(int iduNum){
		int size = iduNum+4;
		byte[] buffer = new byte[size];
		buffer[0] = 0x02;
		buffer[1] = (byte)(size);
		buffer[2] = (byte)105;
		for (int i = 3; i < size-1; i++) {
			buffer[i] = (byte)(i-3);
		}
		short crc8 = Utils.makeCRC8(buffer, size-1);
		buffer[size-1] = (byte) (crc8);
		return buffer;
	}

	public byte[] makeDataPacket(){
		int size = 14;
		byte[] buffer = new byte[size];
		buffer[0] = 0x02;
		buffer[1] = (byte)size;
		buffer[2] = (byte)107;
		for (int i = 3; i < size-1; i++) {
			buffer[i] = (byte)(i-3);
		}
		short crc8 = Utils.makeCRC8(buffer, size-1);
		buffer[size-1] = (byte) (crc8);
		return buffer;
	}

	public int getData(List<DataVO> dataList, int position) {

		if (dataList == null) {
			Utils.printLog(Utils.LogType.ERR, "dataList is null..");
			return EMPTY_DATA;
		}

		Utils.printLog(Utils.LogType.DEBUG, "getData / size: " + dataList.size());

		List<DataVO> bitDataList = new ArrayList<>();
		for (DataVO data : dataList) {
			Utils.printLog(Utils.LogType.DEBUG, "data: " + data.toString());

			List<Integer> posArray = data.getPosByte();
			if (data.getPosBit() == null) {
				Utils.printLog(Utils.LogType.DEBUG, "byte check / posArray: " + posArray + " / position: " + position);
				if (posArray.contains(position)) {
					int ret = getByteValue(position, data.getPosByte(), data.getIntValue());
					Utils.printLog(Utils.LogType.DEBUG, "data: " + data.toString() + " / ret: " + ret);
					return ret;
				}
			} else {
				if (posArray.contains(position)) {
					bitDataList.add(data);
				}
			}

		}
		Utils.printLog(Utils.LogType.DEBUG, "mDataList: " + dataList.size());
		Utils.printLog(Utils.LogType.DEBUG, "bitDataList: " + bitDataList.size());
		if (bitDataList.size() > 0) {
			return getBitValue(bitDataList);
		}
		return EMPTY_DATA;
	}

	public int getData(String pageType, int position) {

		List<DataVO> dataList = null;
		for (ProtocolModel pm : mProtocolList) {
			Utils.printLog(Utils.LogType.DEBUG, "getData / pageType: " + pageType + " / pm: " + pm.pageName + " / c: " + (pm.pageName.equals(pageType)));
			if (pm.pageName.equals(pageType)) {
				dataList = pm.mData;
				break;
			}
		}

		if (dataList == null) {
			Utils.printLog(Utils.LogType.ERR, "dataList is null..");
			return EMPTY_DATA;
		}

		Utils.printLog(Utils.LogType.DEBUG, "getData / pageType: " + pageType + " / size: " + dataList.size());

		List<DataVO> bitDataList = new ArrayList<>();
		for (DataVO data : dataList) {
			Utils.printLog(Utils.LogType.DEBUG, "data: " + data.toString());

			List<Integer> posArray = data.getPosByte();
			if (data.getPosBit() == null) {
				Utils.printLog(Utils.LogType.DEBUG, "byte check / posArray: " + posArray + " / position: " + position);
				if (posArray.contains(position)) {
					int r = getByteValue(position, data.getPosByte(), data.getIntValue());
					Utils.printLog(Utils.LogType.DEBUG, "data: " + data.toString() + " /r: " + r);
					return r;
				}
			} else {
				if (posArray.contains(position)) {
					bitDataList.add(data);
				}
			}

		}
		Utils.printLog(Utils.LogType.DEBUG, "mDataList: " + dataList.size());
		Utils.printLog(Utils.LogType.DEBUG, "bitDataList: " + bitDataList.size());
		if (bitDataList.size() > 0) {
			return getBitValue(bitDataList);
		}
		return EMPTY_DATA;
	}

	private int getBitValue(List<DataVO> bitDataList) {
		List<Integer> onBitList = new ArrayList<>();
		for (DataVO item : bitDataList) {
			List<Integer> bitArray = item.getPosBit();
			for (int i = 0 ; i < bitArray.size() ; i++) {
				if ((((item.getIntValue() >> i) & 0x01) == 0)? false : true) {
					onBitList.add(bitArray.get(i));
				}
			}
		}
		Collections.sort(onBitList);

		int retVal = 0;
		for (Integer item : onBitList) {
			retVal += Math.pow(2, item);
		}
		Utils.printLog(Utils.LogType.DEBUG, "retVal: " + retVal);

		return retVal;
	}


	private int getByteValue(int position, List<Integer> posByte, int value) {
		if (posByte == null || posByte.size() <= 0) {
			Utils.printLog(Utils.LogType.ERR, "error2");
			return EMPTY_DATA;
		}
		Utils.printLog(Utils.LogType.DEBUG, "position: " + position + " / posByte: " + posByte + " / value: " + value);

		if (posByte.size() == 1) {
			return value;
		} else {
			int index = posByte.indexOf(position);
			Utils.printLog(Utils.LogType.DEBUG, "index : " + index);
			if (index != -1) {
				int tmp = (value >> (8*index)) & 0xff;
				Utils.printLog(Utils.LogType.DEBUG, "tmp : " + tmp);
				return tmp;
			} else {
				Utils.printLog(Utils.LogType.ERR, "error3");
				return EMPTY_DATA;
			}
		}
	}

}

