package common;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.json.simple.JSONArray;

public class Utils implements IProtocolParserId {

	private static final boolean DEBUG_STATUS = false;
	
	public enum LogType {
		INFO, DEBUG, ERR
	}

	public static void printLog(LogType type, String message) {

		StackTraceElement[] stacks = new Throwable().getStackTrace();
		StackTraceElement beforeStack = stacks[1];
		String printMsg = message + " [" + beforeStack.getClassName() + "." + beforeStack.getMethodName() + "()]";

		switch (type) {
		case ERR:
			System.err.println(printMsg);
			break;
		case DEBUG:
			if (DEBUG_STATUS) {
				System.out.println(printMsg);
			}
			break;
		default:
			System.out.println(printMsg);
			break;
		}
	}

	public static String byteArrayToHexString(byte[] array){
		if (array == null) {
			return "";	// mv_review
		}
		return byteArrayToHexString(array, array.length);
	}

	public static String byteArrayToHexString(byte[] array, int size){
		StringBuilder tempString = new StringBuilder();
		tempString.append("[");
		for(int i=0; i< array.length && i< size ;i++){
			String tempStr = String.format("%X",Utils.byteToUnsignedInt(array[i]));
			if(tempStr.length() == 1){
				tempString.append("0");
			}	
			tempString.append(tempStr);
			if(i+1 != size){
				tempString.append(" ");
			}
		}
		tempString.append("]");
		return tempString.toString();
	}

	public static int byteToUnsignedInt(byte value){
		int data = value & (byte)127;
		if(value < 0){
			data += 128;
		}
		return data;
	}

	public static byte[] convertToByte(LinkedList<Byte> byteList, int startPos, int endPos) {
		if (byteList == null || byteList.size() == 0 || startPos > endPos || endPos + 1 > byteList.size()) {
			return null;
		}

		int len = endPos - startPos + 1;
		byte[] retByteArr = new byte[len];

		int pos = 0;
		for (int i = startPos; i < endPos + 1; i++) {
			retByteArr[pos] = byteList.get(i);
			pos++;
		}

		return retByteArr;

	}

	public static boolean checkCRC8(byte[] buffer, int length, byte crc8){
		byte makeCRC8 = makeCRC8(buffer,length);
		if(makeCRC8 == crc8){
			return true;
		}else{
			return false;
		}
	}

	public static boolean checkCRC16(byte[] buffer, int length, byte crc16H, byte crc16L){
		short makeCRC16 = makeCRC16(buffer,length);

		byte temp1 = (byte) (makeCRC16 >> 8);
		byte temp2 = (byte) (makeCRC16 & 0xff);

		if(temp1 == crc16H && temp2 == crc16L){
			return true;
		}
		else if(temp2  == crc16H && temp1 == crc16L){	// add GHP3 070123
			return true;
		}
		else
		{
			return false;
		}
	}

	public static byte makeCRC8(byte[] buffer, int length) {
		int crc = 0;
		int c = 0;
		int i = 0;
		int j = 0;

		for (i = 0; i < length; i++) {
			c = buffer[i] & 0xff;
			for (j = 0; j < 8; j++) {
				if ((((crc ^ c)) & 1) == 1) {
					crc = (crc >> 1) ^ 0x85;
				} else {
					crc >>= 1;
				}

				c >>= 1;
			}
		}
		return (byte) (crc & 0x000000ff);
	}

	public static short makeCRC16(byte[] buffer, int length) {
		int i=0;
		char uiCrc = 0;
		char uiTemp = 0;
		char uiQuick = 0;

		for(i=0; i<length; i++)
		{
			uiTemp =   (char) ((uiCrc >> 8) ^ ((short)0xff & buffer[i]));
			uiCrc <<= 8;
			uiQuick =  (char) (uiTemp ^ (uiTemp >> 4));
			uiCrc ^= uiQuick;
			uiQuick <<= 5;
			uiCrc ^= uiQuick;
			uiQuick <<= 7;
			uiCrc ^= uiQuick;
		}
		return (short) (uiCrc);
	}

	public static void removeLinkedList(LinkedList<Byte> byteList, int len) {
		if (byteList == null || byteList.size() == 0 || len <= 0) {
			return;
		}

		for (int i = 0; i < len; i++) {
			byteList.removeFirst();
		}

		return;

	}

	public static List<Integer> convertToInt(JSONArray jsonArray){
		if (jsonArray == null) {
			return null;
		}

		List<Integer> dataList = new ArrayList<>();
		try {
			for(Object obj : jsonArray){
				Long tmp = (Long) obj;
				dataList.add(tmp.intValue());
			}
		} catch (Exception e) {
			Utils.printLog(Utils.LogType.ERR, e.getMessage());
			dataList.clear();
		}
		return dataList;
	}

	public static String getHexValueStr(int value) {
		byte[] tmp = new byte[1];
		tmp[0] = (byte)value;
		return String.format("%X",Utils.byteToUnsignedInt(tmp[0]));
	}

	public static String convertIntArrToString(List<Integer> input) {
		if (input == null || input.size() == 0) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for (Integer i : input) {
			sb.append(Integer.toString(i));
			sb.append(",");
		}
		int size = sb.length();
		sb.deleteCharAt(size-1);
		sb.append("]");
		return sb.toString();
	}

}
