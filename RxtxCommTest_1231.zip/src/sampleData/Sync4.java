package sampleData;

import java.util.ArrayList;
import java.util.List;

import common.IProtocolParserId;
import data.DataVO;

public class Sync4 implements IProtocolParserId{

	public static List<DataVO> makeSystemData(String pageName, int pageCount, int iduCount, int hruCount) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, pageCount, SYSTEM_INFO_PAGE_NO, new int[]{2}, null, 100)); 
		dataList.add(new DataVO(pageName, pageCount, SYSTEM_INFO_PRODUCT_TYPE, new int[]{3}, null, 30));
		dataList.add(new DataVO(pageName, pageCount, SYSTEM_INFO_TOTAL_IDU_NUM, new int[]{28}, null, iduCount));
		dataList.add(new DataVO(pageName, pageCount, SYSTEM_INFO_TOTAL_HRU_NUM, new int[]{29}, null, hruCount));
		return dataList;
	}

	public static List<DataVO> makeCycleData(String pageName, int pageCount) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, pageCount, CYCLE_PAGE_NO, new int[]{2}, null, 101+pageCount));
		dataList.add(new DataVO(pageName, pageCount, ODU_HEADER_ID_FAN1_TRACE, new int[]{9}, null, 10));
		/*
		dataList.add(new DataVO(DEFAULT_HEADER_ID_ERROR_UNIT_NUMBER, pageName, new int[]{3}, new int[]{2,3,4}, 1)); 
		dataList.add(new DataVO(DEFAULT_HEADER_ID_OPER_MODE, pageName, new int[]{3}, new int[]{0,1}, 1));

		dataList.add(new DataVO(ODU_HEADER_ID_INV1_TARGET, pageName, new int[]{4}, null, 200));
		dataList.add(new DataVO(ODU_HEADER_ID_INV1_TRACE, pageName, new int[]{5}, null, 100));
		dataList.add(new DataVO(ODU_HEADER_ID_INV2_TARGET, pageName, new int[]{6}, null, 200));
		dataList.add(new DataVO(ODU_HEADER_ID_INV2_TRACE, pageName, new int[]{7}, null, 200));
		dataList.add(new DataVO(ODU_HEADER_ID_FAN1_TARGET, pageName, new int[]{8}, null, 190));
		dataList.add(new DataVO(ODU_HEADER_ID_FAN1_TRACE, pageName, new int[]{9}, null, 150));
		dataList.add(new DataVO(ODU_HEADER_ID_FAN2_TRACE, pageName, new int[]{10}, null, 150));
		dataList.add(new DataVO(ODU_HEADER_ID_HIGHPRESSURE_TARGET, pageName, new int[]{11}, null, 50));
		dataList.add(new DataVO(ODU_HEADER_ID_LOWPRESSURE_TARGET, pageName, new int[]{12}, null, 60));
		dataList.add(new DataVO(DEFAULT_HEADER_ID_ERROR_NUMBER, pageName, new int[]{13}, null, 34));

		dataList.add(new DataVO(ODU_HEADER_ID_PORT_4WAY, pageName, new int[]{17}, new int[]{7}, 0));
		dataList.add(new DataVO(ODU_HEADER_ID_PORT_RECEIVER_OUT, pageName, new int[]{17}, new int[]{6}, 0));
		dataList.add(new DataVO(ODU_HEADER_ID_PORT_RECEIVER_IN, pageName, new int[]{17}, new int[]{5}, 0));
		dataList.add(new DataVO(ODU_HEADER_ID_PORT_ACCUM_VALVE, pageName, new int[]{17}, new int[]{4}, 0));
		dataList.add(new DataVO(ODU_HEADER_ID_PORT_INV2_PREHEAT, pageName, new int[]{17}, new int[]{3}, 1));
		dataList.add(new DataVO(ODU_HEADER_ID_PORT_INV_PREHEAT, pageName, new int[]{17}, new int[]{2}, 1));
		dataList.add(new DataVO(ODU_HEADER_ID_HEX_VALVE, pageName, new int[]{17}, new int[]{1}, 1));
		// 17(0) 균유 밸브

		dataList.add(new DataVO(ODU_HEADER_ID_PORT_HEX_LOW_VALVE, pageName, new int[]{18}, new int[]{4}, 0));
		dataList.add(new DataVO(ODU_HEADER_ID_PORT_HEX_HIGH_VALVE, pageName, new int[]{18}, new int[]{3}, 0));
		dataList.add(new DataVO(ODU_HEADER_ID_SUCTION_VALVE, pageName, new int[]{18}, new int[]{0}, 0));

		dataList.add(new DataVO(ODU_HEADER_ID_COMP2_OIL_LEVEL, pageName, new int[]{19}, new int[]{1}, 0));
		dataList.add(new DataVO(ODU_HEADER_ID_COMP1_OIL_LEVEL, pageName, new int[]{19}, new int[]{0}, 0));

		dataList.add(new DataVO(ODU_HEADER_ID_MAIN_EEV, pageName, new int[]{20}, null, 0));	//20	(main1 EEV 개도)/8
		dataList.add(new DataVO(ODU_HEADER_ID_SUB_EEV, pageName, new int[]{21}, null, 0));	//21	(Main2 EEV 개도) / 8
		dataList.add(new DataVO(ODU_HEADER_ID_SC_EEV, pageName, new int[]{22}, null, 0));	//22	(과냉각 EEV 개도)/8							
		dataList.add(new DataVO(ODU_HEADER_ID_VI_EEV1, pageName, new int[]{23}, null, 0));	//23	VI EEV1 / 8							
		dataList.add(new DataVO(ODU_HEADER_ID_VI_EEV2, pageName, new int[]{24}, null, 0));	//24	VI EEV2 / 8							
		dataList.add(new DataVO(ODU_HEADER_ID_OIL_EQ_EEV, pageName, new int[]{25}, null, 0));	//25	Oil EQ EEV / 8	

		dataList.add(new DataVO(ODU_HEADER_ID_AIR_TEMP, pageName, new int[]{26}, null, 0));	//26	공기온도 ad 값							
		dataList.add(new DataVO(ODU_HEADER_ID_HIGHPRESSURE_TRACE, pageName, new int[]{27}, null, 0));	//27	현재 고압 ad 값							
		dataList.add(new DataVO(ODU_HEADER_ID_LOWPRESSURE_TRACE, pageName, new int[]{28}, null, 0));	//28	현재 저압 ad 값							
		dataList.add(new DataVO(ODU_HEADER_ID_SUCTION_TEMP, pageName, new int[]{29}, null, 0));	//29	흡입온도 ad 값							
		dataList.add(new DataVO(ODU_HEADER_ID_INV1_DISCHARGE_TEMP, pageName, new int[]{30}, null, 0));	//30	Comp1 토출온도 ad 값							
		dataList.add(new DataVO(ODU_HEADER_ID_INV2_DISCHARGE_TEMP, pageName, new int[]{31}, null, 0));	//31	Comp2 토출온도 ad 값

		dataList.add(new DataVO(ODU_HEADER_ID_HEAT_EXCHANGER_TEMP, pageName, new int[]{33}, null, 0));	//33	열교환기 온도 ad 값							
		dataList.add(new DataVO(ODU_HEADER_ID_HEAT_EXCHANGER_UP_TEMP, pageName, new int[]{34}, null, 0));	//34	열교환기 상부 온도 ad값							
		dataList.add(new DataVO(ODU_HEADER_ID_HEAT_EXCHANGER_DOWN_TEMP, pageName, new int[]{35}, null, 0));	//35	열교환기 하부 온도 ad값							
		dataList.add(new DataVO(ODU_HEADER_ID_SC_PIPE_IN_TEMP, pageName, new int[]{36}, null, 0));	//36	과냉각기 입구 온도 ad 값							
		dataList.add(new DataVO(ODU_HEADER_ID_SC_PIPE_OUT_TEMP, pageName, new int[]{37}, null, 0));	//37	과냉각 출구 온도 ad값							
		dataList.add(new DataVO(ODU_HEADER_ID_SC_PIPE_LIQUID_TEMP, pageName, new int[]{38}, null, 0));	//38	액관온도 ad 값							
		//39	실내 배관입구 평균 온도 ad값							

		dataList.add(new DataVO(ODU_HEADER_ID_INV_ERROR, pageName, new int[]{41}, new int[]{6,7}, 1)); //41(7,6)	Inv error정보(01:inv 1, 10:inv 2)		
		dataList.add(new DataVO(ODU_HEADER_ID_FAN_ERROR, pageName, new int[]{41}, new int[]{4,5}, 1)); //41(5,4)	Fan error정보(01:fan 1, 10:fan 2)
		//41(3) PFC	동작
		//41(2) PFC	동작1
		//41(1) Power Relay2
		//41(0) Power Relay1

		//42(7) Fan과부하1
		//42(3) Ipm 제한2
		//42(2) Ipm 제한1
		//42(1) COMP과부하2
		//42(0) COMP과부하1

		dataList.add(new DataVO(ODU_HEADER_ID_INV1_INPUT_CURRENT, pageName, new int[]{43}, null, 0));	//43	inverter1 입력전류 * 5							
		dataList.add(new DataVO(ODU_HEADER_ID_INV1_INPUT_VOLTAGE, pageName, new int[]{44}, null, 0));	//44	inverter1 입력전압 / 5							
		dataList.add(new DataVO(ODU_HEADER_ID_INV2_INPUT_CURRENT, pageName, new int[]{45}, null, 0));	//45	inverter2 입력전류 * 5							
		dataList.add(new DataVO(ODU_HEADER_ID_INV2_INPUT_VOLTAGE, pageName, new int[]{46}, null, 0));	//46	inverter2 입력전압 / 5							
		dataList.add(new DataVO(ODU_HEADER_ID_INV1_FREQUENCY_INPUT_VOLTAGE, pageName, new int[]{47}, null, 0));	//47	inv1 input power 주파수							
		dataList.add(new DataVO(ODU_HEADER_ID_INV2_FREQUENCY_INPUT_VOLTAGE, pageName, new int[]{48}, null, 0));	//48	inv2 input power 주파수

		dataList.add(new DataVO(ODU_HEADER_ID_INV1_UP_CURRENT, pageName, new int[]{51}, null, 0));	//51	comp1 상전류 * 5							
		dataList.add(new DataVO(ODU_HEADER_ID_INV2_UP_CURRENT, pageName, new int[]{53}, null, 0));	//53	comp2 상전류 * 5							
		dataList.add(new DataVO(ODU_HEADER_ID_FAN1_UP_CURRENT, pageName, new int[]{55}, null, 0));	//55	fan 1 상전류 * 10							
		dataList.add(new DataVO(ODU_HEADER_ID_FAN2_UP_CURRENT, pageName, new int[]{57}, null, 0));	//57	fan 2 상전류 * 10	

		dataList.add(new DataVO(ODU_HEADER_ID_FAN_DC_LINK_VOLTAGE, pageName, new int[]{58}, null, 0));	//58	FAN DC link 전압 / 5							
		dataList.add(new DataVO(ODU_HEADER_ID_INV1_DC_LINK_VOLTAGE, pageName, new int[]{59}, null, 0));	//59	inv1 DC link 전압 / 5							
		dataList.add(new DataVO(ODU_HEADER_ID_INV2_DC_LINK_VOLTAGE, pageName, new int[]{60}, null, 0));	//60	inv2 DC link 전압 / 5							
		dataList.add(new DataVO(ODU_HEADER_ID_INV1_IPM_TEMP, pageName, new int[]{61}, null, 0));	//61	inv1 IPM 온도 센서 DEC 값							
		dataList.add(new DataVO(ODU_HEADER_ID_INV2_IPM_TEMP, pageName, new int[]{62}, null, 0));	//62	inv2 IPM 온도 센서 DEC 값							
		dataList.add(new DataVO(ODU_HEADER_ID_FAN_HEATSINK_TEMP, pageName, new int[]{63}, null, 0));	//63	Fan HeatSink 온도 ad 값							

		//64(3) 입력전압제한2	
		//64(2) 입력전압제한1	
		//64(1) 입력전류제한2	
		//64(0) 입력전류제한1
		*/
		return dataList;
	}

	public static List<DataVO> makeCommuncationCount(String pageName, int pageCount) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, pageCount, "comm_count_page_number", new int[]{2}, null, 105));
		return dataList;
	}
	
	public static List<DataVO> makeDevData(String pageName, int pageCount) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, pageCount, "dev_count_page_number", new int[]{2}, null, 107));
		return dataList;
	}
	
	public static List<DataVO> makeIduData(String pageName, int pageCount) {
		List<DataVO> dataList = new ArrayList<>();
		dataList.add(new DataVO(pageName, pageCount , "idu_data_page_number", new int[]{2}, null, 106));
		dataList.add(new DataVO(pageName, pageCount, "idu_number", new int[]{3}, null, pageCount));
		return dataList;
	}

}
