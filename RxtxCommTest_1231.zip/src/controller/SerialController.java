package controller;

import java.util.LinkedList;

import common.Utils;
import data.Protocol;
import network.Serial;
import view.MainView;

public class SerialController {
	public static final int DATA_TX_START = 0;
	public static final int DATA_TX_STOP = 1;
	
	private MainView mMainView;
	private Serial mSerial;
	private Protocol mProtocol;
	
	private LinkedList<Byte> mBufferQueue = new LinkedList<>();
	private int mTxHeaderType = -1;
	private int mTxPacketCount = 0;
	
	private boolean mSendFlag = false;
	
	
	public SerialController(MainView mainView, Protocol protocol) {
		this.mMainView = mainView;
		this.mProtocol = protocol;
		mSerial = new Serial(this);
	}

	public void connect(String portNum, int baudRate, String modelName) {
		Utils.printLog(Utils.LogType.INFO, "connect / portNum : " + portNum + " / baudRate : " + baudRate);
		try {
			mSerial.connect(portNum, baudRate);
			if (mBufferQueue == null) {
				mBufferQueue = new LinkedList<>();
			}
			mBufferQueue.clear();
//			mProtocol.makeModelData(modelName);
//			mMainView.setProtocolItem(mProtocol.getDataList());	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public Protocol getProtocol() {
		return this.mProtocol;
	}

	public void doDataTxSendStop(int type) {
		switch (type) {
		case DATA_TX_START:
			mSendFlag = true;
			try {
				mSerial.write();
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case DATA_TX_STOP:
			mSendFlag = false;
			break;
		default:
			break;
		}
		
	}


	public void stop() {
		// TODO 
		Utils.printLog(Utils.LogType.INFO, "stop fail..");
//		if (serial != null) {
//			serial.disconnect();
//		}
	}
	
	public void setTxHeaderType(int headerType) {
		Utils.printLog(Utils.LogType.INFO, "headerType : " + headerType);
		mTxHeaderType = headerType;
		mTxPacketCount = 0;
	}
	
	public int getTxHeaderType() {
		return mTxHeaderType;
	}
	
	public void updateTxPacketCount() {
		mTxPacketCount++;
		if (mTxPacketCount > 10) {
			mTxPacketCount = 0;
			mTxHeaderType = 1;
		}
	}
	
	public int getTxPacketCount() {
		return mTxPacketCount;
	}
	
	public boolean getSendFlag() {
		return mSendFlag;
	}
	
	public void setSendFlag(boolean sendFlag) {
		this.mSendFlag = sendFlag;
	}

	
	
}
